"use client";
import { useEffect, useRef, useState } from "react";

// 앱 전체에서 한 번에 하나만 재생
let current = null;
function fmt(s) { if (!isFinite(s) || s < 0) return "0:00"; const m = Math.floor(s / 60), x = Math.floor(s % 60); return `${m}:${String(x).padStart(2, "0")}`; }

/**
 * 선택지 칸 안의 미리듣기. 첫 줄 = ▶ + children(제목·설명), 재생 중이면 아래 줄에 진행바·시간.
 * <VoicePreview src="..."><div className="opt-body">…</div></VoicePreview>
 */
export default function VoicePreview({ src, children, onError }) {
  const audio = useRef(null);
  const [state, setState] = useState("idle"); // idle | loading | playing | paused
  const [t, setT] = useState(0);
  const [dur, setDur] = useState(0);

  useEffect(() => () => { if (audio.current) { audio.current.pause(); if (current === audio.current) current = null; } }, []);

  function ensure() {
    if (audio.current) return audio.current;
    const a = new Audio(src);
    a.preload = "metadata";
    a.ontimeupdate = () => setT(a.currentTime);
    a.ondurationchange = () => setDur(a.duration);
    a.onloadedmetadata = () => setDur(a.duration);
    a.onplaying = () => setState("playing");
    a.onended = () => { setState("paused"); setT(0); };
    a.onerror = () => { setState("idle"); onError?.("미리듣기를 만들지 못했어요. 잠시 뒤 다시 눌러 주세요."); };
    audio.current = a;
    return a;
  }
  async function toggle(e) {
    e.stopPropagation();
    const a = ensure();
    if (state === "playing") { a.pause(); setState("paused"); return; }
    if (current && current !== a) { current.pause(); }
    current = a;
    setState("loading");
    try { await a.play(); } catch { setState("idle"); }
  }
  function seek(e) { e.stopPropagation(); const a = ensure(); a.currentTime = Number(e.target.value); setT(a.currentTime); }

  return (
    <>
      <div className="opt-row">
        <button className={`iconbtn ${state === "playing" ? "on" : ""}`} onClick={toggle} aria-label="미리듣기">{state === "loading" ? "…" : state === "playing" ? "❚❚" : "▶"}</button>
        {children}
      </div>
      {state !== "idle" && (
        <div className="vp" onClick={(e) => e.stopPropagation()}>
          <input type="range" min="0" max={dur || 1} step="0.05" value={Math.min(t, dur || 1)} onChange={seek} aria-label="재생 위치" />
          <span className="vp-time">{fmt(t)} / {fmt(dur)}</span>
        </div>
      )}
    </>
  );
}
