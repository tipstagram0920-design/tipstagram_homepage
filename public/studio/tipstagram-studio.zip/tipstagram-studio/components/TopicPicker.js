"use client";
import { useState } from "react";

export const SOURCES = [
  { id: "news", label: "📰 최근 뉴스에서", desc: "이번 주 기사 제목을 읽고 골라요", busy: "이번 주 뉴스를 모으고 있어요" },
  { id: "blog", label: "✍️ 블로그 글에서", desc: "네이버 블로그 글 제목에서", busy: "블로그 글 제목을 모으고 있어요" },
  { id: "youtube", label: "📺 유튜브 영상에서", desc: "많이 본 영상 제목에서 각도를 잡아요", busy: "유튜브 영상 제목을 모으고 있어요" },
  { id: "trend", label: "🔥 지금 뜨는 검색어에서", desc: "실시간 인기 검색어 중 내 분야와 닿는 것", busy: "지금 뜨는 검색어를 보고 있어요" },
  { id: "question", label: "💬 자주 묻는 질문에서", desc: "사람들이 밤에 검색창에 치는 고민", busy: "사람들이 묻는 질문을 모으고 있어요" },
  { id: "season", label: "📅 계절·기념일에서", desc: "오늘 날짜·절기·행사에 맞는 이야기", busy: "오늘 날짜에 맞는 소재를 고르고 있어요" },
  { id: "evergreen", label: "📌 언제나 쓰는 노하우", desc: "분야 안 여러 갈래에서 골고루", busy: "분야 안에서 골고루 고르고 있어요" },
];

async function post(url, body) {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || "문제가 생겼어요. 다시 눌러 주세요.");
  return j;
}

/** 1단계 공통: 출처 버튼 → 소재 3개 → 고르기. onPick(topic) */
export default function TopicPicker({ onPick, placeholder = "예: 50대 무릎 통증 줄이는 걷기" }) {
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [topics, setTopics] = useState([]);
  const [hint, setHint] = useState("");
  const [sourceId, setSourceId] = useState(null);
  const [info, setInfo] = useState(null);
  const [seen, setSeen] = useState([]);

  async function load(src, more = false) {
    const def = SOURCES.find((x) => x.id === src) || SOURCES[SOURCES.length - 1];
    setSourceId(src); setError(""); setBusy(`${def.busy}… (20초쯤 걸려요)`);
    if (!more) setTopics([]);
    try {
      const j = await post("/api/magazine/topics", { source: src, hint, exclude: seen });
      setTopics(j.topics || []);
      setSeen((prev) => [...new Set([...prev, ...(j.topics || []).map((t) => t.title)])]);
      setInfo({ itemCount: j.itemCount || 0, source: src, empty: j.empty || "" });
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  return (
    <>
      <p className="sub">어디서 소재를 찾을지 고르세요. 누르면 그곳에서만 좁게 찾아서 빨라요.</p>
      {error && <div className="notice warn">{error}</div>}
      {busy && <div className="notice info"><span className="spinner" />{busy}</div>}
      <div className="sources">
        {SOURCES.map((x) => (
          <button key={x.id} className={`srcbtn ${sourceId === x.id ? "on" : ""}`} onClick={() => load(x.id)} disabled={!!busy}>
            <div className="l">{x.label}</div>
            <div className="d">{x.desc}</div>
          </button>
        ))}
      </div>
      <div className="card" style={{ padding: 18, marginTop: 14 }}>
        <div className="muted" style={{ marginBottom: 8 }}>원하는 방향이 있으면 먼저 적고 위 버튼을 누르세요. 바로 이 소재로 가려면 오른쪽 버튼 (선택)</div>
        <div className="row">
          <input type="text" value={hint} onChange={(e) => setHint(e.target.value)} placeholder={placeholder} style={{ flex: 3 }} />
          <button className="btn small" style={{ flex: 1 }} disabled={!hint.trim() || !!busy} onClick={() => onPick({ title: hint.trim(), angle: "", why: "직접 입력", kind: "evergreen", refs: [] })}>이 소재로 할래요</button>
        </div>
      </div>

      {info?.empty && !busy && topics.length === 0 && <div className="notice info" style={{ marginTop: 18 }}>{info.empty}</div>}
      {topics.length > 0 && (
        <>
          <h2 style={{ marginTop: 26 }}>{SOURCES.find((x) => x.id === sourceId)?.label} 고른 소재</h2>
          {info && !busy && (
            <div className="muted" style={{ marginBottom: 14 }}>
              {["news", "blog", "youtube", "trend", "question"].includes(info.source)
                ? info.itemCount > 0 ? `${info.itemCount}건을 읽고 분야 안에 있는 것만 골랐어요.` : "거기서 가져온 게 없어서 분야 안 노하우로 골랐어요."
                : ""}
              {seen.length > 3 ? ` 지금까지 보여드린 ${seen.length}개와 겹치지 않게 골랐어요.` : ""}
            </div>
          )}
          {topics.map((t, i) => (
            <div key={i} className="card selectable" onClick={() => onPick(t)}>
              <div className={`badge ${t.kind === "news" ? "news" : t.kind === "ref" ? "ref" : ""}`}>
                {t.kind === "news" ? "📰 이번 주 뉴스" : t.kind === "ref" ? SOURCES.find((x) => x.id === t.source)?.label.replace(/에서$/, "") : "📌 언제나 쓰는 노하우"}
              </div>
              <h2>{t.title}</h2>
              <div style={{ fontSize: 19, marginBottom: 6 }}>{t.angle}</div>
              <div className="muted">{t.why}</div>
              {t.refs?.length > 0 && <div className="muted" style={{ fontSize: 15, marginTop: 8 }}>참고: {t.refs.slice(0, 2).join(" · ")}</div>}
            </div>
          ))}
          {!busy && (
            <div className="row" style={{ marginBottom: 10 }}>
              <button className="btn ghost" onClick={() => load(sourceId, true)}>같은 곳에서 3개 더</button>
            </div>
          )}
        </>
      )}
    </>
  );
}
