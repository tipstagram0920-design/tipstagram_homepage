"use client";
import { useEffect, useRef, useState } from "react";

/**
 * 오래 걸리는 일의 진행 막대. 실제 %를 모르면 예상 시간(estimateMs)에 맞춰 천천히 차오르고(최대 95%), 끝나면 100%.
 * props: label, percent(실제 값이 있으면), estimateMs, done
 */
export default function ProgressBar({ label, percent = null, estimateMs = 60000, done = false }) {
  const [fake, setFake] = useState(0);
  const start = useRef(Date.now());
  useEffect(() => { start.current = Date.now(); setFake(0); }, [label]);
  useEffect(() => {
    if (percent !== null || done) return;
    const t = setInterval(() => {
      const el = Date.now() - start.current;
      setFake(Math.min(95, Math.round(100 * (1 - Math.exp(-el / (estimateMs * 0.6))))));
    }, 250);
    return () => clearInterval(t);
  }, [percent, done, estimateMs]);
  const v = done ? 100 : percent !== null ? Math.min(100, Math.max(0, Math.round(percent))) : fake;
  return (
    <div className="progress">
      <div className="progress-top"><span>{done ? "✓ " : <span className="spinner" />}{label}</span><strong>{v}%</strong></div>
      <div className="progress-track"><div className="progress-fill" style={{ width: `${v}%` }} /></div>
    </div>
  );
}
