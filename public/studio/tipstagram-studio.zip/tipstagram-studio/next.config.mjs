/** @type {import('next').NextConfig} */
const nextConfig = {
  serverExternalPackages: ["playwright", "ffmpeg-static"],
  images: { unoptimized: true },
  devIndicators: false,
};
export default nextConfig;
