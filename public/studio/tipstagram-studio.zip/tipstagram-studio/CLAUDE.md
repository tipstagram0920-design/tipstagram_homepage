# CLAUDE.md — 팁스타그램 수익화 스튜디오 설치팩

이 폴더는 수강생이 **자기 컴퓨터에서** 쓰는 콘텐츠 제작 도구다.
사용자는 개발자가 아니다(40~50대, 인스타로 장사하는 분). **사용자가 "설치해줘"라고 하면 아래 절차를 네가 직접 끝까지 한다.**
사용자에게 명령어를 치라고 시키지 말고, 네가 실행해라. 설명은 쉬운 한국어로, 한 번에 한 가지씩.

> 상위 폴더에 다른 CLAUDE.md 가 있어도 **이 폴더 안에서는 이 문서만** 따른다.

## 이 앱은 무엇인가
- 브라우저에서 열리는 로컬 웹앱(http://localhost:3777). 서버도 사용자 컴퓨터에서 돈다. 인터넷 서비스에 올리지 않는다.
- 글은 **사용자 컴퓨터에 설치된 Claude Code(`claude -p`)** 가 쓴다. **API 키를 넣는 곳이 없고, 만들지도 않는다.**
- 소재는 자동으로 찾지 않는다. 사용자가 **출처 버튼**을 누르면 그곳에서만 좁게 모은다(`lib/sources.js`, 전부 키 없음): 📰 구글 뉴스 RSS · ✍️ 네이버 블로그 검색 HTML · 📺 유튜브 검색 HTML(조회수순) · 🔥 구글 트렌드 RSS(KR) · 💬 네이버 지식iN(못 가져오면 클로드가 질문을 떠올림) · 📅 오늘 날짜 · 📌 노하우. 브랜드의 **분야(계정 주제)** 가 소재의 범위이고, 말투 예시는 말투만 참고한다(프롬프트에 명시). 중복 방지는 `output/` 지난 소재 + 이번 세션에 보여준 제목(`exclude`). 뉴스 소재는 **서로 다른 매체 2곳 이상**일 때만 뉴스로 표시한다(코드로 강제). **분야 밖 소재는 절대 내지 않는다**: 클로드가 소재마다 `fit`(1~5) 을 매기고 4 미만(트렌드는 5 미만)은 서버에서 버린다. 맞는 게 없으면 3개를 채우지 않고 "닿는 소재가 없어요"를 보여준다.
- 사진형 스타일: 배경 사진은 Openverse(키 불필요, 익명 분당 20회·하루 200회, `lib/photos.js`)에서 **CC0·퍼블릭 도메인 → CC BY** 순으로 찾는다. ND·SA·NC 는 코드에서 거른다. CC BY 면 카드 왼쪽 아래에 출처를 작게 찍는다. 사용자가 카드마다 자기 사진을 올릴 수도 있다(`/api/magazine/photo`). 받은 사진은 `data/photo-cache/` 에 캐시.
- 스타일 레퍼런스: 사용자가 올린 카드뉴스 캡처를 `claude -p --allowedTools Read` 로 읽어 색·정렬·장식 값(`data/style-reference.json`)으로 바꾸고, 그 값으로 그린다(`lib/templates.js` 의 custom).
- 저장은 DB 없이 `data/`(브랜드 설정)와 `output/날짜/`(결과물) 폴더에 파일로 한다.
- 카드 이미지는 HTML/CSS 로 그려 Playwright(Chromium)가 1080×1350 PNG 로 찍는다. 글꼴은 `public/fonts/` 의 Pretendard(무료·상업용 가능)를 같이 넣어뒀다.
- **릴스 만들기** (`/reels`): ① 카드뉴스로 ② 레퍼런스 따라찍기 ③ 사진으로. 엔진은 `lib/reels/`: 대본은 `claude -p`(`script.js`, 훅 공식 `prompts/hooks.md`·구조 `prompts/scripts.md`), 장면 그림은 Gemini(`gemini.js`·`images.js`, 글자·그림체 검수 후 최대 3회 재시도), 영상은 FFmpeg(`ffmpeg-static`, `compose.js`)+ASS 자막(`ass.js`, Pretendard OTF `assets/fonts/`)+프리셋 4종(`presets/*.json`, 수정본은 `presets/custom/`). 오래 걸리는 작업은 `jobs.js` 가 서버 안에서 돌리고 화면은 `/api/reels/jobs/{id}` 를 1.5초마다 본다.
- **Gemini 키는 외부 키 중 유일**하다. 설정 화면에서 넣고 `data/keys.json` 에만 저장. 글 분석(영상 읽기·검수·사진 설명)은 무료 등급으로 되지만 **그림 생성은 구글 프로젝트에 결제를 켜야** 된다(무료 등급은 하루 한도 0 → 429). 키 확인 때 그림 한 장을 시험해 `keys.json.image.ok` 에 기록하고 화면에 안내한다. 키가 없거나 그림이 막히면 카드뉴스는 **자막 없는 카드 슬라이드** 로 자동 전환.
- 내 스타일(대본 샘플·훅 공식·행동 유도·금지어)은 `prompts/custom/my-style.json`, 자막 모양 수정은 `presets/custom/{id}.json`. 기본값 파일은 절대 덮어쓰지 않는다.
- 카드뉴스→릴스 대본은 **카드 순서를 그대로** 따른다(표지→본문 카드당 장면→마무리). 순위가 아닌 카드를 순위로 바꾸지 않고, 제목 띠는 카드뉴스 제목을 줄인 것(`lib/reels/cardnews.js` 의 source 규칙). 레퍼런스 영상의 형식을 흉내 내면 안 된다(사용자 지적 10/20).
- 카드뉴스→릴스 기본은 **프리셋 5 유튜브 정보형**(`layout: banner`: 위 검은 띠에 titleTop(노랑)+titleMain(흰색), 브랜드색 구분선, 가운데 그림, 말풍선 자막, 아래 띠에 계정 이름). 대본이 `titleTop/titleMain/say` 를 낸다.
- **목소리(TTS)는 Gemini TTS**(`tts.js`, `gemini-2.5-flash-preview-tts`, 남 3·여 3 프리셋 목소리, 미리듣기는 `data/voices/` 캐시). 장면 길이는 말 길이에 맞춰 늘어난다. Chatterbox 같은 파이썬 TTS 는 설치 부담 때문에 쓰지 않는다. 배경음악은 `assets/bgm/{bright,calm,tension}.mp3` 가 있으면 붙고(목소리 있으면 15%) 없으면 무음.
- 장면 그림은 결과 화면에서 "AI로 다시"(`/api/reels/scene-image`) 또는 "내 사진"(`/api/reels/scene-upload`)으로 바꾸고 "이 그림들로 영상 다시 만들기". **"AI로 다시"는 그 장면 하나만, 그 장면의 대사(`say`)에 맞춰 새로 그린다** (사용자 지시 10/20). 대본에 미리 적어 둔 `visual` 을 다시 그리면 같은 그림만 나오므로, `lineToVisual()`(`images.js`)이 대사를 영어 장면 설명 한 문장으로 바꿔 쓴다(실패하면 `visual` 로 돌아감). 그래서 `job.result.scenes` 에 장면을 남긴다 — 화면을 새로 고쳐도 대사를 알 수 있어야 한다.
- **훅은 세게** (사용자 지시 10/20). `prompts/hooks.md` 는 사장님의 "후킹 패턴 50선" 범주(구체 숫자 · 잃는 것(공포·후회) · 미공개 · 통념 뒤집기)를 ★ 공식으로 두고, 훅 3개 중 **최소 1개는 ★ 에서** 뽑게 한다(`script.js` 의 지시문에도 못 박음). 예전 규칙에 있던 "과장·공포 조장 금지" 는 훅을 무난하게 만들어서 걷어냈다. **대신 금지선은 하나다 — 없는 사실을 만들지 않는다**(소재에 없는 숫자·자격·희소성, 치료·완치 약속). "약한 훅 → 센 훅" 표가 파일 안에 있으니 그 톤을 기준으로 본다.
- **자막 줄바꿈은 의미 단위로** (사용자 지시 10/20). `wrapCaption()`(`ass.js`)은 앞줄을 꽉 채우지 않고, 넘길 수 있는 자리마다 **의미가 끊기는 정도 → 두 줄 길이 차이** 순으로 점수를 매겨 고른다. 꾸미는 말로 끝나거나(관형사·관형형), 의존명사·조사로 시작하거나, 숫자로 끝나거나, 한 글자만 줄 끝에 남는 자리는 쓰지 않는다. 12자 안에 좋은 자리가 없으면 길이만 보고 가장 고르게 나눈다. 사진으로 릴스 만들기(`/reels/photos`)는 메뉴에서 뺐다(코드는 남아 있음).

## "설치해줘" 절차 (이 순서대로, 멈추지 말고)

> 보통은 홈페이지에서 받은 **설치 파일(.command / .bat)** 이 이 절차를 다 한다(휴대용 Node 를 `runtime/` 에 받고, Claude Code 를 설치하고, 아래 스크립트를 돌린다). 이 절차는 그게 실패했거나 사용자가 zip 을 직접 풀었을 때 쓴다.

0. **먼저 확인**: 지금 작업 폴더가 이 CLAUDE.md 가 있는 폴더인지 (`package.json` 에 `"name": "tipstagram-studio"`). 아니면 이 폴더로 이동한다.
1. **운영체제 확인** — Mac 인지 Windows 인지 (`uname` 또는 `ver`). 이후 경로·명령을 거기에 맞춘다.
2. **Node.js 확인** — `node -v` 가 20.9 이상이어야 한다.
   - 없거나 낮으면: 사용자에게 "https://nodejs.org 에서 LTS(왼쪽 초록 버튼)를 내려받아 설치해 주세요. 끝나면 '설치했어요'라고 말씀해 주세요"라고 안내하고, 설치되면 **터미널을 새로 열어야** `node` 가 잡힌다는 점을 기억해 다시 확인한다.
   - Mac 에 Homebrew 가 있으면 `brew install node` 로 네가 직접 설치해도 된다.
3. **Claude Code 확인** — `claude --version`. 이 문서를 읽고 있다면 이미 설치돼 있다. 안 잡히면 `where claude`(Win)/`which claude`(Mac)로 경로를 찾아 둔다.
4. **설치 스크립트 실행** — 아래 한 줄이 의존성 설치 → Chromium 다운로드 → 빌드 → 바탕화면 아이콘 → 실행 확인까지 다 한다. 3~6분 걸린다.
   ```
   node scripts/install.mjs
   ```
   출력에 `❌ 실패:` 가 나오면 **그 줄과 `→` 힌트를 읽고 아래 표대로 고친 뒤 다시 실행**한다. 이미 끝난 단계는 `--skip-install`, `--skip-build` 로 건너뛸 수 있다.
5. **성공하면** (`✅ 설치가 끝났어요!`) 사용자에게 알려주고, **실행까지 확인**한다:
   - Mac: `open "$HOME/Desktop/팁스타그램 스튜디오.command"`
   - Windows: `start "" "%USERPROFILE%\Desktop\팁스타그램 스튜디오.lnk"` (OneDrive 바탕화면이면 설치 출력에 찍힌 경로를 쓴다)
   - 브라우저에 화면이 뜨면 "첫 화면의 **클로드에게 물어보기** 버튼을 눌러 보세요. 답이 나오면 끝이에요"라고 안내한다.
6. 마지막으로 **브랜드 설정부터 하라고** 안내한다. (계정 이름·로고·색·주제·말투 예시 → 저장)

## 문제가 생겼을 때 (증상 → 원인 → 네가 할 일)

| 증상 | 원인 | 할 일 |
|---|---|---|
| `node: command not found` / `'node'은(는) 내부 또는 외부 명령...` | Node 미설치, 또는 설치 후 터미널을 안 닫음 | 2단계 안내. 설치 후 새 터미널에서 재시도 |
| `Node.js 가 너무 오래됐어요` | 20.9 미만 | nodejs.org LTS 로 재설치 |
| `claude 명령을 찾지 못했어요` | PATH 문제 | `which`/`where` 로 경로를 찾아 `data/system.json` 의 `claudePath` 에 절대경로를 적어준다 |
| 화면의 "클로드에게 물어보기"가 `로그인이 안 되어 있어요` | claude 미로그인 | 사용자에게 "터미널에서 `claude` 를 한 번 실행해 로그인하세요"라고 안내. 네가 대신 로그인할 수는 없다 |
| `클로드 코드 프로그램이 오래됐어요` / `version_too_old` | claude 구버전 | `claude update` 실행 후 재시도. 안 되면 `data/system.json` 의 `model` 을 `"haiku"` 나 `"claude-sonnet-4-6"` 로 바꿔 본다 |
| `npm install 이 실패` / `ECONNRESET` / `ETIMEDOUT` | 인터넷·회사 프록시 | 와이파이 확인 후 재시도. 회사망이면 집에서 |
| `EACCES` / `permission denied` (Mac) | 폴더 권한 | 폴더가 `다운로드`나 `문서` 안에 있는지 확인. `sudo` 쓰지 말 것. 안 되면 폴더를 `~/Documents/tipstagram-studio` 로 옮겨 재시도 |
| `Chromium 다운로드가 실패` | 네트워크 | `node node_modules/playwright/cli.js install chromium` 재실행 |
| `카드를 그릴 브라우저(Chromium)가 없어요` (화면) | 위와 같음 | 위와 같음 |
| `EADDRINUSE` / `서버가 켜지지 않았어요` | 3777 포트 사용 중 | 이미 켜진 스튜디오 창이 있는지 확인. 없으면 `STUDIO_PORT=3800 node scripts/start.mjs` 로 포트 변경 |
| 빌드 실패 (`Type error`, `Module not found`) | 코드 문제 | 오류 파일을 열어 고친다. 고친 뒤 `node scripts/install.mjs --skip-install` |
| Windows: 아이콘 더블클릭 시 창이 바로 꺼짐 | 경로 한글/공백, 실행 정책 | 폴더 안의 `시작.bat` 로 실행해 오류 확인. `.lnk` 가 없으면 `.bat` 아이콘을 쓴다 |
| Windows: `이 시스템에서 스크립트를 실행할 수 없으므로` | PowerShell 실행 정책 | `.lnk` 생성만 영향. `시작.bat` 를 바탕화면에 복사해 준다 |
| Mac: "확인되지 않은 개발자" 경고 | Gatekeeper | 아이콘 오른쪽 클릭 → 열기. 또는 `xattr -d com.apple.quarantine "<파일>"` |
| 이미지에 글꼴이 깨짐(네모) | 폰트 파일 없음 | `public/fonts/Pretendard-*.woff2` 4개가 있는지 확인 |
| 소재 화면에 `거기서 가져온 게 없어서` | 인터넷 없음, 또는 네이버·유튜브 페이지 구조 변경 | 소재는 그래도 나온다(클로드 지식). 구조 변경이면 `lib/sources.js` 의 정규식을 고친다 |
| 사진형 카드가 어두운 배경만 나옴 / `맞는 사진을 못 찾아` | Openverse 요청 제한(분당 20회)이나 인터넷 | 1분 뒤 "다른 사진 찾기". 또는 카드 눌러 "내 사진 올리기" |
| 릴스: `이 키는 무료 등급이라 그림 생성이 막혀` | 구글 프로젝트 결제 미설정 | 설정 화면 안내대로 결제 켜고 키 확인 재실행. 안 켜도 카드 슬라이드·레퍼런스 분석은 됨 |
| 릴스: `영상 프로그램(FFmpeg)을 실행하지 못했어요` | ffmpeg-static 바이너리 없음/차단(윈도우 백신) | `npm install` 재실행, `node scripts/check.mjs` 로 확인 |
| 릴스 자막이 네모로 깨짐 | `assets/fonts/*.otf` 없음 | 파일 3개 확인 |
| 레퍼런스 주소 가져오기 실패 | 인스타 로그인 벽 (정상) | 화면 안내대로 앱에서 저장한 영상 파일을 올린다 |
| 프롬프터 QR 로 폰에서 안 열림 | 다른 와이파이, 맥 방화벽 | 같은 와이파이 확인, 방화벽 허용 |
| `레퍼런스를 읽지 못했어요` | 이미지가 너무 크거나 claude 가 Read 도구를 못 씀 | 10MB 아래 PNG/JPG 로 다시. `data/reference/` 폴더에서 `claude -p --allowedTools Read` 가 되는지 확인 |

점검 한 번에: `node scripts/check.mjs`

## 절대 규칙
1. **API 키·토큰을 요구하거나 저장하지 않는다. `.env` 파일을 만들지 않는다.** 클로드 호출은 `lib/claude.js` 의 `claude -p` 뿐이다.
2. `data/` 와 `output/` 은 사용자 자산이다. 지우거나 덮어쓰지 않는다.
3. 이 폴더 밖의 파일을 수정하지 않는다.
4. 코드에 사용자 컴퓨터의 절대경로를 박지 않는다. 경로는 `process.cwd()`/`data/system.json` 에서 읽는다. (설치 때 만드는 바탕화면 아이콘만 예외)
5. 서버는 localhost 에서만 돈다. 외부 공개(ngrok 등)하지 않는다.

## 화면 원칙 (기능을 추가할 때)
- **간격·정렬·크기는 `docs/ui-guide.md` 가 기준이다.** 선택지는 `.optgrid > .opt`, 섹션은 `.section` + `h2` + `.section-sub`, 결과 동작은 `.actions`. 인라인 style 로 새 간격을 만들지 않는다.
- 사용자는 40~50대. **큰 글씨(기본 20px), 큰 버튼(높이 68px), 한 화면에 한 가지 일.**
- 전문 용어 금지: "렌더링" → "그리기", "API" → "클로드", "빌드" → "준비".
- 오류는 **무엇을 하면 되는지**까지 한 문장으로. (`lib/claude.js` `friendlyMessage` 참고)
- 오래 걸리는 일은 "~하는 중이에요 (20초쯤 걸려요)" 처럼 예상 시간을 쓴다.
- 문구는 전부 한국어, 존댓말.

## 폴더 지도
```
CLAUDE.md            이 문서
scripts/install.mjs  설치 한 방 (OS 분기 · 바탕화면 아이콘 생성)
scripts/start.mjs    실행 (서버 켜고 브라우저 열기)
scripts/check.mjs    점검
시작.command / 시작.bat  폴더 안 실행 파일 (바탕화면 아이콘이 없을 때)
app/                 화면 (Next.js App Router, JS)
  page.js            첫 화면: 큰 버튼 3개 + 클로드 연결 확인
  brand/             브랜드 설정 → data/brand.json
  magazine/          매거진 카드뉴스 3단계
  groupbuy/          공구 콘텐츠 (준비 중)
  reels/             릴스 만들기 메뉴 · cardnews · reference · photos · prompter(검은 화면 프롬프터+QR)
  library/           내가 만든 것: output 전체 목록(카드뉴스·릴스·레퍼런스), 재생, 폴더 열기, 삭제(output/날짜/작업 깊이만, 확인 후)
  settings/          Gemini 연결 · 내 스타일 맞추기(StyleSettings.js)
  api/               claude/test · brand/{styles,style-sample,style-ref} · magazine/* · reels/{cardnews-list,script,jobs,scene-image,video,reference/*,photos/*,prompter} · settings/{gemini,my-style,presets} · output · open
lib/claude.js        claude -p 호출 (CLAUDE* 환경변수 제거, 모델 지정, 친절한 오류 문구)
lib/templates.js     카드 템플릿 4종 (정보형·감성형·리스트형·사진형) + 레퍼런스 custom. HTML/CSS + 브랜드 색 팔레트
lib/photos.js        Openverse 사진 검색·다운로드·캐시 (키 없음)
lib/render.js        Playwright 로 PNG 찍기
lib/prompts.js       소재 제안 · 카드뉴스 생성 · 레퍼런스 분석 프롬프트, 글자수 정리
lib/news.js          구글 뉴스 RSS 수집(키 없음) · 오늘 날짜 문장
lib/sources.js       소재 출처 7종 수집(뉴스·블로그·유튜브·트렌드·질문·계절·노하우)
lib/store.js         data/·output/ 파일 저장
lib/ffmpeg.js        ffmpeg-static 경로
lib/reels/           릴스 엔진: script(대본) · gemini · images · styles(그림체 6종) · ass(자막) · compose(FFmpeg) · presets · jobs · cardnews · photos · reference · mystyle · tts(준비 중)
prompts/             hooks.md · scripts.md · video-presets.md (기본값) / custom/ (내 스타일, 깃 제외)
presets/             1~4.json 영상 프리셋 / custom/ (수정본, 깃 제외)
assets/fonts/        Pretendard OTF 3종 (영상 자막용) · assets/bgm/ (선택)
public/styles/       그림체 샘플 6장 (설치팩 동봉)
docs/reels-spec.md   릴스 기능 명세(개발 기준)
content/             말투 규칙 · 카드뉴스 글자수 규칙 · 공구 원칙 (프롬프트에 붙는 문서)
public/fonts/        Pretendard woff2 4종
public/sample/       썸네일용 CC0 샘플 사진 1장
data/                brand.json · logo.* · system.json · style-reference.json · reference/ (설치·사용 중 생성)
output/날짜/시각-주제/  카드뉴스: 01.png… · 캡션.txt · content.json
output/날짜/릴스_…/     릴스: 릴스.mp4 · images/ · 대본.json · 캡션.txt (레퍼런스: 분석.json · 촬영가이드.md)
```

## 명령어
```bash
node scripts/install.mjs            # 설치 (전부)
node scripts/install.mjs --skip-install --skip-build   # 아이콘·실행 확인만 다시
node scripts/start.mjs              # 실행
node scripts/check.mjs              # 점검 (FFmpeg·Gemini·그림체 샘플·배경음악 포함)
node scripts/test-reels.mjs         # 릴스 엔진 테스트: 프리셋 4종 영상 (output/_test)
node scripts/gen-style-samples.mjs  # 그림체 샘플 재생성 (운영자용, Gemini 결제 필요)
npm run dev                         # 개발 모드 (코드 고칠 때)
```
