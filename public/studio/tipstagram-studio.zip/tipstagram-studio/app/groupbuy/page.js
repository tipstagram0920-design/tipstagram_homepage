import Link from "next/link";

export default function GroupBuy() {
  return (
    <>
      <div className="topbar">
        <Link href="/" className="back">← 처음으로</Link>
      </div>
      <h1>공구 콘텐츠 만들기</h1>
      <p className="sub">아직 준비 중이에요. 다음 단계에서 제안서·캡션·스토리 만들기가 들어와요.</p>
      <div className="card">
        <h2>이 기능이 지킬 원칙</h2>
        <ol style={{ paddingLeft: 24, lineHeight: 1.7 }}>
          <li>써보지 않은 제품의 후기를 지어내지 않아요.</li>
          <li>가격·혜택·오픈일이 정해지기 전엔 [미정]으로 둬요.</li>
          <li>공구 글에는 광고 표기를 꼭 넣어요.</li>
          <li>실제 재고·기간이 없으면 &quot;선착순&quot;, &quot;오늘 마감&quot;을 쓰지 않아요.</li>
        </ol>
      </div>
      <Link href="/" className="btn ghost block">처음으로 돌아가기</Link>
    </>
  );
}
