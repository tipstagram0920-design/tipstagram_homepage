"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

const KINDS = [{ id: "all", name: "전체" }, { id: "cardnews", name: "카드뉴스" }, { id: "reel", name: "릴스" }, { id: "reference", name: "레퍼런스" }];
const KIND_LABEL = { cardnews: "🖼️ 카드뉴스", reel: "🎬 릴스", reference: "🎯 레퍼런스" };

export default function Library() {
  const [items, setItems] = useState(null);
  const [kind, setKind] = useState("all");
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const [playing, setPlaying] = useState(null);

  async function load() { try { const j = await (await fetch("/api/library")).json(); setItems(j.items || []); } catch { setError("목록을 불러오지 못했어요."); } }
  useEffect(() => { load(); }, []);
  function flash(t) { setMsg(t); setTimeout(() => setMsg(""), 2500); }

  async function remove(it) {
    if (!window.confirm(`"${it.title}" 을(를) 지울까요?\n폴더 안의 이미지·영상·글이 모두 지워지고 되돌릴 수 없어요.`)) return;
    try {
      const r = await fetch("/api/library", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ dir: it.dir }) });
      const j = await r.json(); if (!r.ok) throw new Error(j.message);
      setItems(items.filter((x) => x.dir !== it.dir)); flash("지웠어요");
    } catch (e) { setError(e.message); }
  }
  async function openFolder(it) { try { await fetch("/api/open", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ dir: it.dir }) }); flash("폴더를 열었어요"); } catch { setError("폴더를 열지 못했어요."); } }

  const list = (items || []).filter((it) => kind === "all" || it.kind === kind);

  return (
    <>
      <div className="topbar"><Link href="/" className="back">← 처음으로</Link></div>
      <h1>내가 만든 것</h1>
      <p className="sub">지금까지 만든 카드뉴스·릴스가 모두 여기 있어요. 안 쓰는 건 지워도 돼요.</p>
      {error && <div className="notice warn">{error}</div>}
      {msg && <div className="notice ok">{msg}</div>}
      <div className="row" style={{ marginBottom: 18 }}>
        {KINDS.map((k) => <button key={k.id} className="btn ghost small" style={{ flex: 1, borderColor: kind === k.id ? "var(--accent)" : "var(--line)" }} onClick={() => setKind(k.id)}>{k.name}{items ? ` ${k.id === "all" ? items.length : items.filter((x) => x.kind === k.id).length}` : ""}</button>)}
      </div>
      {items === null && <div className="muted">불러오는 중…</div>}
      {items !== null && list.length === 0 && <div className="notice info">아직 없어요. <Link href="/magazine" style={{ textDecoration: "underline" }}>매거진 콘텐츠 만들기</Link>에서 첫 카드뉴스를 만들어 보세요.</div>}
      <div className="libgrid">
        {list.map((it) => (
          <div key={it.dir} className="card" style={{ padding: 14, marginBottom: 0 }}>
            <div className="thumb" style={{ aspectRatio: it.kind === "cardnews" ? "1080/1350" : "9/16", background: "#222" }} onClick={() => it.video && setPlaying(playing === it.dir ? null : it.dir)}>
              {playing === it.dir && it.video ? <video src={it.video} controls autoPlay playsInline style={{ width: "100%", height: "100%", background: "#000" }} /> : it.cover ? <img src={it.cover} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", color: "#bbb", fontSize: 40 }}>{it.kind === "reference" ? "🎯" : "🎬"}</div>}
              {it.video && playing !== it.dir && <div className="playmark">▶</div>}
            </div>
            <div className="badge" style={{ marginTop: 10 }}>{KIND_LABEL[it.kind]}</div>
            <div style={{ fontSize: 18, fontWeight: 800, lineHeight: 1.3 }}>{it.title}</div>
            <div className="muted" style={{ fontSize: 15 }}>{it.date} {it.time} · {it.sub}</div>
            <div style={{ display: "grid", gap: 6, marginTop: 10 }}>
              {it.kind === "cardnews" && <Link href={`/reels/cardnews?dir=${encodeURIComponent(it.dir)}`} className="btn small scene-btn" style={{ background: "#1F4E9C" }}>🎬 릴스로 만들기</Link>}
              {it.kind === "reference" && <Link href={`/reels/prompter?dir=${encodeURIComponent(it.dir)}`} className="btn small scene-btn">📱 프롬프터</Link>}
              <button className="btn ghost small scene-btn" onClick={() => openFolder(it)}>📂 폴더 열기</button>
              <button className="btn ghost small scene-btn" style={{ color: "var(--warn)" }} onClick={() => remove(it)}>🗑 지우기</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
