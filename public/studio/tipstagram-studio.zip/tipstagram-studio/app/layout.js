import "./globals.css";

export const metadata = { title: "팁스타그램 수익화 스튜디오" };

export default function RootLayout({ children }) {
  return (
    <html lang="ko">
      <body>
        <main className="wrap">{children}</main>
      </body>
    </html>
  );
}
