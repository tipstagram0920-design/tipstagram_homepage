import { spawn } from "node:child_process";
import { safeOutputPath } from "@/lib/store";
export const dynamic = "force-dynamic";

/** 결과 폴더를 탐색기/파인더로 연다 (output/ 안만). */
export async function POST(req) {
  try {
    const { dir } = await req.json();
    const abs = safeOutputPath(dir || ".");
    if (process.platform === "darwin") spawn("open", [abs], { detached: true, stdio: "ignore" }).unref();
    else if (process.platform === "win32") spawn("explorer", [abs], { detached: true, stdio: "ignore", windowsHide: true }).unref();
    else spawn("xdg-open", [abs], { detached: true, stdio: "ignore" }).unref();
    return Response.json({ ok: true, dir: abs });
  } catch (e) {
    return Response.json({ message: "폴더를 열지 못했어요: " + e.message }, { status: 500 });
  }
}
