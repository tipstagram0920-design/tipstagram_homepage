import fs from "node:fs";
import path from "node:path";
import { loadPreset, PRESET_IDS } from "@/lib/reels/presets";
import { ROOT } from "@/lib/store";
export const dynamic = "force-dynamic";

function customFile(id) { return path.join(ROOT, "presets", "custom", `${id}.json`); }
function baseOf(id) { return JSON.parse(fs.readFileSync(path.join(ROOT, "presets", `${id}.json`), "utf8")); }

export async function GET(_req, { params }) {
  const { id } = await params;
  const n = Number(id);
  if (!PRESET_IDS.includes(n)) return Response.json({ message: "없는 프리셋" }, { status: 404 });
  return Response.json({ preset: loadPreset(n), base: baseOf(n), customized: fs.existsSync(customFile(n)) });
}
/** body: { caption:{size,yPercent,color,box}, enter:{type} } 중 바꾼 것만 → presets/custom/{id}.json */
export async function PUT(req, { params }) {
  const { id } = await params;
  const n = Number(id);
  if (!PRESET_IDS.includes(n)) return Response.json({ message: "없는 프리셋" }, { status: 404 });
  const b = await req.json().catch(() => ({}));
  const cur = fs.existsSync(customFile(n)) ? JSON.parse(fs.readFileSync(customFile(n), "utf8")) : {};
  const next = { ...cur, caption: { ...(cur.caption || {}), ...(b.caption || {}) }, enter: { ...(cur.enter || {}), ...(b.enter || {}) } };
  if (next.caption.size) next.caption.size = Math.min(110, Math.max(36, Number(next.caption.size)));
  if (next.caption.yPercent) next.caption.yPercent = Math.min(80, Math.max(45, Number(next.caption.yPercent)));
  if (next.caption.color && !/^#[0-9a-fA-F]{6}$/.test(next.caption.color)) delete next.caption.color;
  if (next.caption.box && !["dark", "brand", "none"].includes(next.caption.box)) delete next.caption.box;
  if (next.enter.type && !["rise-fade", "word-pop", "typing", "slide-left", "fade"].includes(next.enter.type)) delete next.enter.type;
  fs.mkdirSync(path.dirname(customFile(n)), { recursive: true });
  fs.writeFileSync(customFile(n), JSON.stringify(next, null, 2), "utf8");
  return Response.json({ preset: loadPreset(n), customized: true });
}
export async function DELETE(_req, { params }) {
  const { id } = await params;
  const n = Number(id);
  try { fs.unlinkSync(customFile(n)); } catch {}
  return Response.json({ preset: loadPreset(n), customized: false });
}
