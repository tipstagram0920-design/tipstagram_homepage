import { getMyStyle, saveMyStyle, likeScript, resetMyStyle, defaultHookFormulas } from "@/lib/reels/mystyle";
export const dynamic = "force-dynamic";
export async function GET() {
  return Response.json({ style: getMyStyle(), defaultHooks: defaultHookFormulas() });
}
/** body: { style } 저장 / { like: "대본 텍스트" } / { reset: "scriptSamples"|"all" } */
export async function POST(req) {
  const b = await req.json().catch(() => ({}));
  if (b.like) return Response.json({ style: likeScript(b.like), liked: true });
  if (b.reset) return Response.json({ style: resetMyStyle(b.reset === "all" ? null : b.reset) });
  if (b.style) return Response.json({ style: saveMyStyle(b.style) });
  return Response.json({ message: "저장할 내용이 없어요." }, { status: 400 });
}
