import { getGeminiKey, saveGeminiKey, verifyKey, maskKey, saveModels, getModels, getImageStatus, saveImageStatus } from "@/lib/reels/gemini";
export const dynamic = "force-dynamic";

export async function GET() {
  const key = getGeminiKey();
  return Response.json({ connected: Boolean(key), masked: maskKey(key), models: key ? getModels() : null, image: key ? getImageStatus() : null });
}

/** 키 확인 + 저장 */
export async function POST(req) {
  try {
    const { key } = await req.json();
    const k = String(key || "").trim();
    // 구글 키는 AIza… (예전) 또는 AQ.… (새 형식). 점(.)이 들어간다.
    if (!/^[A-Za-z0-9_.\-]{20,}$/.test(k)) return Response.json({ message: "키 모양이 아니에요. AIza 또는 AQ 로 시작하는 긴 글자를 통째로 붙여 넣어 주세요." }, { status: 400 });
    const v = await verifyKey(k);
    saveGeminiKey(k);
    saveModels(v.models);
    saveImageStatus(v.image);
    return Response.json({ connected: true, masked: maskKey(k), models: v.models, image: v.image });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message, detail: e.detail }, { status: 400 });
  }
}

export async function DELETE() {
  saveGeminiKey("");
  return Response.json({ connected: false });
}
