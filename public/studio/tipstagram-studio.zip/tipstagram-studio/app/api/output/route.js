import fs from "node:fs";
import { safeOutputPath } from "@/lib/store";
export const dynamic = "force-dynamic";

/** output/ 안의 이미지를 화면에 보여준다. ?p=2026-10-19/1030-주제/01.png */
export async function GET(req) {
  try {
    const p = new URL(req.url).searchParams.get("p") || "";
    const abs = safeOutputPath(p);
    if (!fs.existsSync(abs)) return new Response("없음", { status: 404 });
    const type = abs.endsWith(".png") ? "image/png" : abs.endsWith(".txt") ? "text/plain; charset=utf-8" : "application/octet-stream";
    return new Response(fs.readFileSync(abs), { headers: { "content-type": type, "cache-control": "no-store" } });
  } catch {
    return new Response("허용되지 않은 경로", { status: 400 });
  }
}
