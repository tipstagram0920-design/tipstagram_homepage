import fs from "node:fs";
import { styleRefPath } from "@/lib/store";
export const dynamic = "force-dynamic";

export async function GET() {
  const p = styleRefPath();
  if (!p || !fs.existsSync(p)) return new Response("none", { status: 404 });
  const ext = p.split(".").pop();
  return new Response(fs.readFileSync(p), { headers: { "content-type": ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg", "cache-control": "no-store" } });
}
