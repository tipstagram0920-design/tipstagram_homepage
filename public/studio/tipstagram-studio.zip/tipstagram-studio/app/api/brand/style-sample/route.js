import fs from "node:fs";
import path from "node:path";
import { ROOT } from "@/lib/store";
export const dynamic = "force-dynamic";

/** 그림체 샘플 이미지 ?id=photo — public/ 정적 서빙은 빌드 시점에 묶이므로 파일을 직접 읽어 보낸다 */
export async function GET(req) {
  const id = String(new URL(req.url).searchParams.get("id") || "").replace(/[^a-z0-9-]/g, "");
  const f = ["png", "jpg", "webp"].map((e) => path.join(ROOT, "public", "styles", `${id}.${e}`)).find((p) => fs.existsSync(p));
  if (!f) return new Response("none", { status: 404 });
  const ext = f.split(".").pop();
  return new Response(fs.readFileSync(f), { headers: { "content-type": ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg", "cache-control": "public, max-age=3600" } });
}
