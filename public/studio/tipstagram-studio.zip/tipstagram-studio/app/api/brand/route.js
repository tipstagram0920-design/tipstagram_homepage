import fs from "node:fs";
import path from "node:path";
import { getBrand, saveBrand, DATA_DIR, ensureDir } from "@/lib/store";
export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json(getBrand());
}

export async function POST(req) {
  try {
    const fd = await req.formData();
    const prev = getBrand();
    const brand = {
      ...prev,
      name: String(fd.get("name") || "").trim().slice(0, 40),
      color: /^#[0-9a-fA-F]{6}$/.test(String(fd.get("color") || "")) ? String(fd.get("color")) : prev.color,
      topic: String(fd.get("topic") || "").trim().slice(0, 60),
    };
    try {
      const tones = JSON.parse(String(fd.get("toneSamples") || "[]"));
      brand.toneSamples = Array.isArray(tones) ? tones.slice(0, 3).map((t) => String(t).slice(0, 1000)) : prev.toneSamples;
    } catch {
      brand.toneSamples = prev.toneSamples;
    }
    const logo = fd.get("logo");
    if (logo && typeof logo === "object" && logo.size > 0) {
      if (logo.size > 5 * 1024 * 1024) return Response.json({ message: "로고 파일이 너무 커요. 5MB 아래로 줄여 주세요." }, { status: 400 });
      const ext = (logo.type === "image/png" ? "png" : logo.type === "image/webp" ? "webp" : "jpg");
      ensureDir(DATA_DIR);
      for (const old of ["logo.png", "logo.jpg", "logo.webp"]) { try { fs.unlinkSync(path.join(DATA_DIR, old)); } catch {} }
      fs.writeFileSync(path.join(DATA_DIR, `logo.${ext}`), Buffer.from(await logo.arrayBuffer()));
      brand.logoFile = `logo.${ext}`;
    }
    const artStyle = String(fd.get("artStyle") || "");
    if (artStyle) brand.artStyle = artStyle.slice(0, 20);
    const ref = fd.get("styleRef");
    if (ref && typeof ref === "object" && ref.size > 0) {
      if (ref.size > 10 * 1024 * 1024) return Response.json({ message: "기준 사진이 너무 커요. 10MB 아래로 줄여 주세요." }, { status: 400 });
      const ext = ref.type === "image/png" ? "png" : ref.type === "image/webp" ? "webp" : "jpg";
      for (const old of ["style-ref.png", "style-ref.jpg", "style-ref.webp"]) { try { fs.unlinkSync(path.join(DATA_DIR, old)); } catch {} }
      fs.writeFileSync(path.join(DATA_DIR, `style-ref.${ext}`), Buffer.from(await ref.arrayBuffer()));
      brand.styleRefFile = `style-ref.${ext}`;
    } else if (fd.get("clearStyleRef")) {
      for (const old of ["style-ref.png", "style-ref.jpg", "style-ref.webp"]) { try { fs.unlinkSync(path.join(DATA_DIR, old)); } catch {} }
      brand.styleRefFile = null;
    }
    saveBrand(brand);
    return Response.json(brand);
  } catch (e) {
    return Response.json({ message: "저장 중 문제가 생겼어요. 다시 눌러 주세요. (" + e.message + ")" }, { status: 500 });
  }
}
