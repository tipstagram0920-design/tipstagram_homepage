import fs from "node:fs";
import path from "node:path";
import { ART_STYLES } from "@/lib/reels/styles";
import { ROOT } from "@/lib/store";
export const dynamic = "force-dynamic";

/** 그림체 목록 + 샘플 이미지 유무 (샘플은 public/styles/{id}.png 로 서빙) */
export async function GET() {
  const styles = ART_STYLES.map((s) => {
    const f = ["png", "jpg", "webp"].map((e) => `${s.id}.${e}`).find((n) => fs.existsSync(path.join(ROOT, "public", "styles", n)));
    return { id: s.id, name: s.name, desc: s.desc, sample: f ? `/api/brand/style-sample?id=${s.id}` : null };
  });
  return Response.json({ styles });
}
