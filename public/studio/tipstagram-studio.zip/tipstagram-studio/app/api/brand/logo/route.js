import fs from "node:fs";
import { logoPath } from "@/lib/store";
export const dynamic = "force-dynamic";

export async function GET() {
  const p = logoPath();
  if (!p || !fs.existsSync(p)) return new Response("no logo", { status: 404 });
  const ext = p.split(".").pop();
  const type = ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg";
  return new Response(fs.readFileSync(p), { headers: { "content-type": type, "cache-control": "no-store" } });
}
