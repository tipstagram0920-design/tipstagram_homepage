import path from "node:path";
import { getBrand, logoDataUri, ROOT } from "@/lib/store";
import { slideHtml, sampleSlides } from "@/lib/templates";
import { fileToDataUri } from "@/lib/photos";
export const dynamic = "force-dynamic";

/** 스타일 고르기 화면의 썸네일(HTML). ?style=info&slide=0 */
export async function GET(req) {
  const url = new URL(req.url);
  const style = url.searchParams.get("style") || "info";
  const idx = Math.min(2, Math.max(0, Number(url.searchParams.get("slide") || 0)));
  const brand = { ...getBrand(), logoDataUri: logoDataUri() };
  const slides = sampleSlides();
  const slide = { ...slides[idx] };
  if (style === "photo") {
    try { slide.photoDataUri = fileToDataUri(path.join(ROOT, "public", "sample", "sample-photo.webp")); } catch {}
  }
  const html = slideHtml({ style, brand, slide, index: idx === 2 ? 6 : idx, total: 7 });
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
}
