import fs from "node:fs";
import path from "node:path";
import { safeOutputPath, ensureDir } from "@/lib/store";
export const dynamic = "force-dynamic";

/** 사진형: 특정 카드의 배경 사진을 사용자가 직접 올린다. multipart: dir, index, image */
export async function POST(req) {
  try {
    const fd = await req.formData();
    const dir = safeOutputPath(String(fd.get("dir") || ""));
    const index = Number(fd.get("index"));
    const file = fd.get("image");
    if (!fs.existsSync(dir) || !Number.isInteger(index)) return Response.json({ message: "카드를 먼저 만들어 주세요." }, { status: 400 });
    if (!file || typeof file !== "object" || !file.size) return Response.json({ message: "사진을 골라 주세요." }, { status: 400 });
    if (file.size > 20 * 1024 * 1024) return Response.json({ message: "사진이 너무 커요. 20MB 아래로 줄여 주세요." }, { status: 400 });
    const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
    const rel = path.join("photos", `${String(index + 1).padStart(2, "0")}-mine.${ext}`);
    ensureDir(path.join(dir, "photos"));
    fs.writeFileSync(path.join(dir, rel), Buffer.from(await file.arrayBuffer()));
    return Response.json({ photoFile: rel });
  } catch (e) {
    return Response.json({ message: "사진을 저장하지 못했어요: " + e.message }, { status: 500 });
  }
}
