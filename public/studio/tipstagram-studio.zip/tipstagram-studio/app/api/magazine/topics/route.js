import { askClaude } from "@/lib/claude";
import { getBrand, pastTopics } from "@/lib/store";
import { topicsPrompt, trendFilterPrompt } from "@/lib/prompts";
import { collect, SOURCES } from "@/lib/sources";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** body: { source, hint, exclude:[이번 세션에 이미 보여준 제목] } */
export async function POST(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const source = SOURCES.some((s) => s.id === body.source) ? body.source : "evergreen";
    const hint = String(body.hint || "").slice(0, 200);
    const exclude = Array.isArray(body.exclude) ? body.exclude.map(String).slice(0, 60) : [];
    const brand = getBrand();
    let items = await collect(source, brand.topic, hint);
    const label = SOURCES.find((s) => s.id === source)?.label || "";
    // 트렌드는 분야와 무관한 검색어가 대부분 → 생성 전에 한 번 거른다. 남는 게 없으면 만들지 않는다.
    if (source === "trend" && items.length) {
      // 1차: 분야 단어가 검색어·관련 기사 제목에 실제로 들어간 것만 (예: "중년 건강" → 중년, 건강)
      const words = String(brand.topic || "").split(/[\s,·/]+/).map((w) => w.trim()).filter((w) => w.length >= 2);
      if (words.length) items = items.filter((it) => words.some((w) => it.title.includes(w)));
      // 2차: 남은 것 중 분야 자체에 관한 것만 클로드가 번호로
      if (items.length) {
        const keep = await askClaude(trendFilterPrompt(brand.topic || "인스타 운영", items), { json: true, timeoutMs: 90_000 }).catch(() => []);
        const idx = new Set((Array.isArray(keep) ? keep : []).map((n) => Number(n) - 1));
        items = items.filter((_, i) => idx.has(i));
      }
      if (items.length === 0) {
        return Response.json({ topics: [], itemCount: 0, source, empty: `지금 뜨는 검색어 중에 '${brand.topic || "내 분야"}'에 관한 게 없어요. 다른 출처를 눌러 보세요.` });
      }
    }
    const past = [...new Set([...exclude, ...pastTopics(30)])].slice(0, 60);
    const raw = await askClaude(topicsPrompt(brand, hint, { source, items, past }), { json: true });
    const list = (Array.isArray(raw) ? raw : raw?.topics || [])
      .slice(0, 3)
      .map((t) => ({
        title: String(t.title || "").trim(),
        why: String(t.why || "").trim(),
        angle: String(t.angle || "").trim(),
        kind: ["news", "ref", "evergreen"].includes(t.kind) ? t.kind : "evergreen",
        refs: Array.isArray(t.refs) ? t.refs.map(String).filter(Boolean).slice(0, 4) : [],
        fit: Number(t.fit) || 0,
        source,
      }))
      .filter((t) => t.title)
      // 출처가 2곳 미만이면 아직 사실이 아니다 → 노하우로 내리고 근거를 지운다
      .map((t) => (t.kind === "news" && t.refs.length < 2 ? { ...t, kind: "evergreen", refs: [] } : t))
      // 이번 세션에 보여준 것과 같은 제목은 뺀다
      .filter((t) => !exclude.includes(t.title))
      // 분야 적합도가 낮으면 버린다 (3개를 채우는 것보다 분야 안에 있는 게 먼저)
      .filter((t) => t.fit >= (source === "trend" ? 5 : 4));
    if (list.length === 0) {
      return Response.json({
        topics: [],
        itemCount: items.length,
        source,
        empty: `${label} 지금은 '${brand.topic || "내 분야"}'와 닿는 소재가 없어요. 다른 출처를 눌러 보세요.`,
      });
    }
    return Response.json({ topics: list, itemCount: items.length, source });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message, detail: e.detail }, { status: 500 });
  }
}
