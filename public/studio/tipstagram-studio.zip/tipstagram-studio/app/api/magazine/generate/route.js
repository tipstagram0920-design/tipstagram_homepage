import { askClaude } from "@/lib/claude";
import { getBrand, getStyleReference } from "@/lib/store";
import { cardnewsPrompt, normalizeCardnews } from "@/lib/prompts";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(req) {
  try {
    const { topic, style } = await req.json();
    if (!topic?.title) return Response.json({ message: "소재를 먼저 골라 주세요." }, { status: 400 });
    const brand = getBrand();
    const referenceMood = style === "custom" ? getStyleReference()?.params?.mood || "" : "";
    const raw = await askClaude(cardnewsPrompt(brand, topic, style, { referenceMood }), { json: true });
    const content = normalizeCardnews(raw);
    return Response.json({ content });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message, detail: e.detail }, { status: 500 });
  }
}
