import fs from "node:fs";
import path from "node:path";
import { askClaude } from "@/lib/claude";
import { getBrand, getStyleReference, saveStyleReference, REFERENCE_DIR, ensureDir } from "@/lib/store";
import { referencePrompt, normalizeReference } from "@/lib/prompts";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function GET() {
  return Response.json(getStyleReference());
}

/** 레퍼런스 이미지 업로드 → 클로드가 생김새를 읽어 디자인 값으로 저장 */
export async function POST(req) {
  try {
    const fd = await req.formData();
    const file = fd.get("image");
    if (!file || typeof file !== "object" || !file.size) return Response.json({ message: "이미지를 골라 주세요." }, { status: 400 });
    if (file.size > 10 * 1024 * 1024) return Response.json({ message: "이미지가 너무 커요. 10MB 아래로 줄여 주세요." }, { status: 400 });
    const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
    ensureDir(REFERENCE_DIR);
    for (const old of fs.readdirSync(REFERENCE_DIR)) fs.unlinkSync(path.join(REFERENCE_DIR, old));
    const name = `reference.${ext}`;
    fs.writeFileSync(path.join(REFERENCE_DIR, name), Buffer.from(await file.arrayBuffer()));

    const raw = await askClaude(referencePrompt(name), { json: true, allowedTools: ["Read"], cwd: REFERENCE_DIR, timeoutMs: 180_000 });
    const params = normalizeReference(raw, getBrand().color);
    const saved = { file: name, params, updatedAt: new Date().toISOString() };
    saveStyleReference(saved);
    return Response.json(saved);
  } catch (e) {
    return Response.json({ message: e.friendly || "레퍼런스를 읽지 못했어요. 다른 이미지로 다시 올려 주세요.", detail: e.detail || e.message }, { status: 500 });
  }
}

export async function DELETE() {
  try { fs.rmSync(REFERENCE_DIR, { recursive: true, force: true }); } catch {}
  try { fs.unlinkSync(path.join(REFERENCE_DIR, "..", "style-reference.json")); } catch {}
  return Response.json({ ok: true });
}
