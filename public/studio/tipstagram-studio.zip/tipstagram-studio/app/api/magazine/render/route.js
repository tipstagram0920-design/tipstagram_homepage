import fs from "node:fs";
import path from "node:path";
import { getBrand, logoDataUri, newOutputDir, OUTPUT_DIR, safeOutputPath, ensureDir } from "@/lib/store";
import { slideHtml } from "@/lib/templates";
import { renderSlides } from "@/lib/render";
import { findPhoto, downloadPhoto, fileToDataUri, photoSearchBlocked } from "@/lib/photos";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** 사진형: 슬라이드마다 사진을 구해 output/.../photos/NN.jpg 로 둔다 (직접 올린 사진이 있으면 그걸 쓴다) */
async function attachPhotos(slides, dir, topic) {
  const photosDir = ensureDir(path.join(dir, "photos"));
  const notes = [];
  const used = new Set();
  for (let i = 0; i < slides.length; i++) {
    const s = slides[i];
    const nn = String(i + 1).padStart(2, "0");
    // 1) 사용자가 올린 사진
    if (s.photoFile) {
      const abs = path.join(dir, s.photoFile);
      if (fs.existsSync(abs)) { s.photoDataUri = fileToDataUri(abs); s.photoCredit = ""; continue; }
    }
    // 2) 검색 (슬라이드 검색어 → 소재 검색어. 한 세트 안에서 같은 사진은 안 쓴다)
    const found = await findPhoto([s.photoQuery, topic?.photoQuery], s.photoIndex || 0, used);
    if (found) used.add(found.url);
    if (found) {
      const dest = path.join(photosDir, `${nn}.jpg`);
      const file = await downloadPhoto(found.url, dest);
      if (file) {
        s.photoDataUri = fileToDataUri(file);
        s.photoCredit = found.credit;
        s.photoFile = path.relative(dir, file);
        continue;
      }
    }
    notes.push(nn);
    s.photoDataUri = null; // 어두운 배경으로 대체
  }
  return notes;
}

/** 슬라이드 PNG 를 만들어 output/날짜/ 에 저장한다. dir 을 주면 같은 폴더에 덮어쓴다(글 고친 뒤 다시 그리기). */
export async function POST(req) {
  try {
    const { content, style, topicTitle, topic, dir: prevDir } = await req.json();
    if (!content?.slides?.length) return Response.json({ message: "만들 내용이 없어요." }, { status: 400 });
    const brand = { ...getBrand(), logoDataUri: logoDataUri() };
    let dir;
    if (prevDir) {
      dir = safeOutputPath(prevDir);
      for (const f of fs.readdirSync(dir)) if (f.endsWith(".png")) fs.unlinkSync(path.join(dir, f));
    } else {
      dir = newOutputDir(topicTitle || content.slides[0]?.title?.split("\n")[0]);
    }
    const slides = content.slides.map((s) => ({ ...s }));
    let photoNotes = [];
    if (style === "photo") photoNotes = await attachPhotos(slides, dir, topic);

    const total = slides.length;
    const htmls = slides.map((slide, i) => slideHtml({ style, brand, slide, index: i, total }));
    const files = await renderSlides(htmls, dir);

    // 저장용 content 에는 data URI 를 빼고 사진 파일 경로·출처만 남긴다
    const savedSlides = slides.map(({ photoDataUri, ...rest }) => rest);
    const captionText = `${content.caption || ""}\n\n${(content.hashtags || []).join(" ")}`.trim();
    fs.writeFileSync(path.join(dir, "캡션.txt"), captionText, "utf8");
    fs.writeFileSync(path.join(dir, "content.json"), JSON.stringify({ style, topic: topic || { title: topicTitle || "" }, brand: { name: brand.name, color: brand.color }, slides: savedSlides, caption: content.caption, hashtags: content.hashtags }, null, 2), "utf8");
    return Response.json({
      dir: path.relative(OUTPUT_DIR, dir),
      absDir: dir,
      slides: savedSlides,
      photoNotes,
      photoBlocked: photoSearchBlocked(),
      images: files.map((f) => ({ path: f, url: `/api/output?p=${encodeURIComponent(path.relative(OUTPUT_DIR, f))}&v=${Date.now()}` })),
    });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message, detail: e.detail }, { status: 500 });
  }
}
