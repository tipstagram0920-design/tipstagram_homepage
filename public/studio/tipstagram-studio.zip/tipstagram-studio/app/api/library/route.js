import { listLibrary, deleteItem } from "@/lib/library";
export const dynamic = "force-dynamic";
export async function GET() {
  return Response.json({ items: listLibrary() });
}
export async function DELETE(req) {
  try {
    const { dir } = await req.json();
    const ok = deleteItem(String(dir || ""));
    return Response.json({ ok });
  } catch (e) {
    return Response.json({ message: e.message }, { status: 400 });
  }
}
