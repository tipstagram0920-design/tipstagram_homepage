import { askClaude } from "@/lib/claude";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST() {
  try {
    const text = await askClaude("인스타 카드뉴스 제목 3개 만들어줘. 주제는 \"작은 가게 사장님을 위한 인스타 운영 팁\"으로 정해서, 되묻지 말고 번호를 붙여 세 줄로만 답해.", { timeoutMs: 120_000 });
    return Response.json({ ok: true, text });
  } catch (e) {
    return Response.json({ ok: false, message: e.friendly || e.message, detail: e.detail }, { status: 500 });
  }
}
