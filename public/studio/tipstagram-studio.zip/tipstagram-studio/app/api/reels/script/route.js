import { getBrand, getStyleReference } from "@/lib/store";
import { generateScript } from "@/lib/reels/script";
import { loadCardnews } from "@/lib/reels/cardnews";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** body: { source: { kind:"cardnews", dir } | { kind:"text", text, structure? } } */
export async function POST(req) {
  try {
    const { source } = await req.json();
    const brand = getBrand();
    let text = "", structure = "auto", allowed = ["A", "E"], meta = {};
    if (source?.kind === "cardnews") {
      const c = loadCardnews(source.dir);
      text = c.source; structure = c.suggestedStructure; allowed = ["A", "B", "C", "D"]; meta = { title: c.content.topic?.title || "", slideCount: c.images.length };
    } else if (source?.kind === "text") {
      text = String(source.text || "").slice(0, 4000); structure = source.structure || "auto"; allowed = source.allowed || ["A", "B", "C", "D", "E", "F"];
    } else return Response.json({ message: "재료가 없어요." }, { status: 400 });
    const script = await generateScript({ brand, source: text, structure, allowedStructures: allowed });
    // 추천 프리셋: 그림체가 수채화·감성 필름이면 3, 아니면 1
    const presetId = 5; // 유튜브 정보형(제목 띠 + 그림 + 말풍선 자막 + 목소리)
    return Response.json({ script, presetId, meta });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message, detail: e.detail }, { status: 500 });
  }
}
