import fs from "node:fs";
import path from "node:path";
import { analyzeVideo, analyzeText } from "@/lib/reels/reference";
import { newReelDir } from "@/lib/reels/index";
import { OUTPUT_DIR, safeOutputPath } from "@/lib/store";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** body: { dir, file } (영상) 또는 { text } (글) */
export async function POST(req) {
  try {
    const b = await req.json();
    let dir, analysis;
    if (b.file) {
      dir = safeOutputPath(b.dir);
      analysis = await analyzeVideo(safeOutputPath(b.file));
    } else if (b.text) {
      dir = b.dir ? safeOutputPath(b.dir) : newReelDir("레퍼런스");
      fs.writeFileSync(path.join(dir, "레퍼런스-글.txt"), String(b.text), "utf8");
      analysis = await analyzeText(String(b.text));
    } else return Response.json({ message: "영상이나 글이 없어요." }, { status: 400 });
    fs.writeFileSync(path.join(dir, "분석.json"), JSON.stringify(analysis, null, 2), "utf8");
    return Response.json({ dir: path.relative(OUTPUT_DIR, dir), analysis });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message, detail: e.detail }, { status: 500 });
  }
}
