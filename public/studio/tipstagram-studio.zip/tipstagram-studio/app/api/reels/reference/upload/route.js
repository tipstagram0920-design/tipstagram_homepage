import fs from "node:fs";
import path from "node:path";
import { newReelDir } from "@/lib/reels/index";
import { OUTPUT_DIR, safeOutputPath } from "@/lib/store";
export const dynamic = "force-dynamic";

/** multipart: video (mp4/mov), dir? */
export async function POST(req) {
  try {
    const fd = await req.formData();
    const f = fd.get("video");
    if (!f || typeof f !== "object" || !f.size) return Response.json({ message: "영상 파일을 골라 주세요." }, { status: 400 });
    if (f.size > 300 * 1024 * 1024) return Response.json({ message: "영상이 너무 커요. 300MB 아래로 해 주세요." }, { status: 400 });
    const dir = fd.get("dir") ? safeOutputPath(String(fd.get("dir"))) : newReelDir("레퍼런스");
    const ext = /quicktime|\.mov$/i.test(f.type || f.name || "") ? "mov" : "mp4";
    const file = path.join(dir, `reference.${ext}`);
    fs.writeFileSync(file, Buffer.from(await f.arrayBuffer()));
    return Response.json({ dir: path.relative(OUTPUT_DIR, dir), file: path.relative(OUTPUT_DIR, file) });
  } catch (e) {
    return Response.json({ message: "영상을 저장하지 못했어요: " + e.message }, { status: 500 });
  }
}
