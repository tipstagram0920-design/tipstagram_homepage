import fs from "node:fs";
import path from "node:path";
import { getBrand, safeOutputPath, OUTPUT_DIR } from "@/lib/store";
import { generateReferenceScript } from "@/lib/reels/script";
import { loadPreset } from "@/lib/reels/presets";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** body: { dir, analysis, hook?, topicHint? } → 대본 + 촬영 가이드 저장 */
export async function POST(req) {
  try {
    const { dir: rel, analysis, hook, topicHint } = await req.json();
    const dir = safeOutputPath(rel);
    const brand = getBrand();
    const script = await generateReferenceScript({ brand, analysis, hook: String(hook || "").slice(0, 60), topicHint: String(topicHint || "").slice(0, 100) });
    const presetId = analysis?.suggestedPreset || 1;
    const preset = loadPreset(presetId);
    const md = [
      `# 레퍼런스 따라찍기 — 촬영 가이드`, "",
      `- 계정: ${brand.name}  · 추천 프리셋: ${preset.name}  · 전체 약 ${script.scenes.reduce((a, s) => a + s.seconds, 0)}초`, "",
      "## 훅 (첫 3초)", ...script.hooks.map((h, i) => `${i + 1}. [${h.formula}] ${h.text}`), "",
      "## 장면별 촬영 가이드", "| 장면 | 초 | 무엇을 찍을지 | 할 말 | 화면 글자 |", "|---|---|---|---|---|",
      ...script.scenes.map((s) => `| ${s.scene} | ${s.seconds} | ${s.shoot} | ${s.say} | ${s.caption} |`), "",
      "## 캡션", script.caption, "", script.hashtags.join(" "), "",
    ].join("\n");
    fs.writeFileSync(path.join(dir, "대본.json"), JSON.stringify({ kind: "reference", presetId, ...script }, null, 2), "utf8");
    fs.writeFileSync(path.join(dir, "촬영가이드.md"), md, "utf8");
    fs.writeFileSync(path.join(dir, "캡션.txt"), `${script.caption}\n\n${script.hashtags.join(" ")}`.trim(), "utf8");
    return Response.json({ dir: path.relative(OUTPUT_DIR, dir), script, presetId, presetName: preset.name });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message, detail: e.detail }, { status: 500 });
  }
}
