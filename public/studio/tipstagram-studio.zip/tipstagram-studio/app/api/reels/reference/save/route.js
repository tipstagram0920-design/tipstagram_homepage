import fs from "node:fs";
import path from "node:path";
import { safeOutputPath, getBrand } from "@/lib/store";
export const dynamic = "force-dynamic";

/** body: { dir, script } — 사용자가 고친 대본을 저장하고 촬영가이드.md·캡션.txt 를 다시 쓴다 */
export async function POST(req) {
  try {
    const { dir: rel, script } = await req.json();
    const dir = safeOutputPath(rel);
    if (!script?.scenes?.length) return Response.json({ message: "저장할 대본이 없어요." }, { status: 400 });
    const cut = (s, n) => String(s ?? "").replace(/\s+/g, " ").trim().slice(0, n);
    const scenes = script.scenes.map((s, i) => ({ scene: i + 1, seconds: Math.min(6, Math.max(1, Number(s.seconds) || 3)), caption: cut(s.caption, 40), emphasis: cut(s.emphasis, 12), say: cut(s.say, 240), shoot: cut(s.shoot, 140), visual: cut(s.visual, 300) })).filter((s) => s.say || s.caption);
    const prev = fs.existsSync(path.join(dir, "대본.json")) ? JSON.parse(fs.readFileSync(path.join(dir, "대본.json"), "utf8")) : {};
    const next = { ...prev, ...script, scenes, caption: String(script.caption || ""), hashtags: Array.isArray(script.hashtags) ? script.hashtags : [], editedAt: new Date().toISOString() };
    fs.writeFileSync(path.join(dir, "대본.json"), JSON.stringify(next, null, 2), "utf8");
    const brand = getBrand();
    const md = [
      `# 레퍼런스 따라찍기 — 촬영 가이드 (수정본)`, "",
      `- 계정: ${brand.name}  · 전체 약 ${scenes.reduce((a, s) => a + s.seconds, 0)}초`, "",
      "## 장면별 촬영 가이드", "| 장면 | 초 | 무엇을 찍을지 | 할 말 | 화면 글자 |", "|---|---|---|---|---|",
      ...scenes.map((s) => `| ${s.scene} | ${s.seconds} | ${s.shoot} | ${s.say} | ${s.caption} |`), "",
      "## 캡션", next.caption, "", next.hashtags.join(" "), "",
    ].join("\n");
    fs.writeFileSync(path.join(dir, "촬영가이드.md"), md, "utf8");
    fs.writeFileSync(path.join(dir, "캡션.txt"), `${next.caption}\n\n${next.hashtags.join(" ")}`.trim(), "utf8");
    return Response.json({ ok: true, script: next });
  } catch (e) {
    return Response.json({ message: e.message }, { status: 500 });
  }
}
