import path from "node:path";
import { newReelDir } from "@/lib/reels/index";
import { fetchInstagramVideo } from "@/lib/reels/reference";
import { OUTPUT_DIR } from "@/lib/store";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

/** body: { url } → 되면 { dir, file }, 안 되면 { failed:true, reason } (에러가 아니라 다음 방법 안내용) */
export async function POST(req) {
  const { url } = await req.json().catch(() => ({}));
  if (!url) return Response.json({ failed: true, reason: "주소를 붙여 넣어 주세요." });
  const dir = newReelDir("레퍼런스");
  const r = await fetchInstagramVideo(String(url).trim(), path.join(dir, "reference.mp4"));
  if (!r.ok) return Response.json({ failed: true, reason: r.reason, dir: path.relative(OUTPUT_DIR, dir) });
  return Response.json({ dir: path.relative(OUTPUT_DIR, dir), file: path.relative(OUTPUT_DIR, r.file) });
}
