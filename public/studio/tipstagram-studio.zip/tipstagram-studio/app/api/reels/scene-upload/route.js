import fs from "node:fs";
import path from "node:path";
import { safeOutputPath, OUTPUT_DIR, ensureDir } from "@/lib/store";
export const dynamic = "force-dynamic";

/** 장면 그림을 내 사진으로 바꾸기. multipart: dir, index, image */
export async function POST(req) {
  try {
    const fd = await req.formData();
    const dir = safeOutputPath(String(fd.get("dir") || ""));
    const index = Number(fd.get("index"));
    const f = fd.get("image");
    if (!fs.existsSync(dir) || !Number.isInteger(index)) return Response.json({ message: "먼저 영상을 만들어 주세요." }, { status: 400 });
    if (!f || typeof f !== "object" || !f.size) return Response.json({ message: "사진을 골라 주세요." }, { status: 400 });
    if (f.size > 25 * 1024 * 1024) return Response.json({ message: "사진이 너무 커요 (25MB 아래로)." }, { status: 400 });
    const ext = f.type === "image/png" ? "png" : f.type === "image/webp" ? "webp" : "jpg";
    ensureDir(path.join(dir, "images"));
    const file = path.join(dir, "images", `scene-${String(index + 1).padStart(2, "0")}-mine.${ext}`);
    fs.writeFileSync(file, Buffer.from(await f.arrayBuffer()));
    const rel = path.relative(OUTPUT_DIR, file);
    return Response.json({ image: rel, url: `/api/output?p=${encodeURIComponent(rel)}&v=${Date.now()}` });
  } catch (e) {
    return Response.json({ message: "사진을 저장하지 못했어요: " + e.message }, { status: 500 });
  }
}
