import { listCardnews } from "@/lib/reels/cardnews";
export const dynamic = "force-dynamic";
export async function GET() {
  return Response.json({ sets: listCardnews(30) });
}
