import { startReelJob } from "@/lib/reels/jobs";
import { loadCardnews } from "@/lib/reels/cardnews";
import { safeOutputPath } from "@/lib/store";
import { fitFor } from "@/lib/reels/photos";
import path from "node:path";
export const dynamic = "force-dynamic";

/** body: { script, presetId, bgm, source?: {kind:"cardnews", dir}, label?, dir?, images?, fits?, endCard? } */
export async function POST(req) {
  try {
    const b = await req.json();
    // 카드 슬라이드 모드: Gemini 없이 카드 원본을 자막 없이 한 장씩 (글이 이미 카드에 있으니 자막을 얹지 않는다)
    if (b.slideMode && b.source?.kind === "cardnews") {
      const c = loadCardnews(b.source.dir);
      const sec = Number(b.secondsPerCard) || 3;
      const script = { scenes: c.images.map(() => ({ seconds: sec, caption: "" })), caption: c.content.caption || "", hashtags: c.content.hashtags || [] };
      const job = startReelJob({ script, presetId: Number(b.presetId) || 1, bgm: b.bgm, images: c.images, fits: c.images.map(() => "contain-center"), label: b.label || `릴스_${c.content.topic?.title || "카드뉴스"}`, slideMode: true });
      return Response.json({ id: job.id });
    }
    if (!b?.script?.scenes?.length) return Response.json({ message: "대본이 없어요." }, { status: 400 });
    let fallbackImages = [];
    if (b.source?.kind === "cardnews") fallbackImages = loadCardnews(b.source.dir).images;
    let images = Array.isArray(b.images) ? b.images.map((p) => (p ? safeOutputPath(p) : null)) : undefined;
    let fits = b.fits;
    if (b.photoMode && images) {
      // 사진 모드: 장면 수만큼 사진을 돌려 쓰고, 세로 사진은 꽉 채우고 가로 사진은 흐린 배경 위에
      const n = images.length;
      images = b.script.scenes.map((_, i) => images[i % n]);
      fits = images.map((f) => (f ? fitFor(f) : "cover"));
    }
    const dir = b.dir ? safeOutputPath(b.dir) : undefined;
    const job = startReelJob({ script: b.script, presetId: Number(b.presetId) || 1, bgm: b.bgm, fallbackImages, label: b.label, dir, images, fits, endCard: b.endCard, voiceId: b.voiceId || "none", banner: b.banner || null });
    return Response.json({ id: job.id });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message }, { status: 500 });
  }
}
