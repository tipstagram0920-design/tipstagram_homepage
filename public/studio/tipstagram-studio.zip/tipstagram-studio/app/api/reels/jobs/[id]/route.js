import { getJob } from "@/lib/reels/jobs";
export const dynamic = "force-dynamic";
export async function GET(_req, { params }) {
  const { id } = await params;
  const j = getJob(id);
  if (!j) return Response.json({ message: "작업을 찾지 못했어요." }, { status: 404 });
  return Response.json({ id: j.id, stage: j.stage, progress: j.progress, done: j.done, error: j.error, result: j.result });
}
