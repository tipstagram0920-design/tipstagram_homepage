import fs from "node:fs";
import { sampleFile, VOICES } from "@/lib/reels/tts";
export const dynamic = "force-dynamic";

/** GET → 목소리 목록 / GET ?voice=Kore → 미리듣기 wav */
export async function GET(req) {
  const voice = new URL(req.url).searchParams.get("voice");
  if (!voice) return Response.json({ voices: VOICES });
  try {
    const f = await sampleFile(voice);
    return new Response(fs.readFileSync(f), { headers: { "content-type": "audio/wav", "cache-control": "public, max-age=86400" } });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message }, { status: 500 });
  }
}
