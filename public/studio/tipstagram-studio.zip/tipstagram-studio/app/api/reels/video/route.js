import fs from "node:fs";
import { safeOutputPath } from "@/lib/store";
export const dynamic = "force-dynamic";

/** output/ 안의 mp4 를 Range 지원으로 보낸다 (사파리·탐색 재생용). ?p=상대경로 */
export async function GET(req) {
  try {
    const p = new URL(req.url).searchParams.get("p") || "";
    const abs = safeOutputPath(p);
    if (!fs.existsSync(abs) || !abs.endsWith(".mp4")) return new Response("없음", { status: 404 });
    const size = fs.statSync(abs).size;
    const range = req.headers.get("range");
    const headers = { "content-type": "video/mp4", "accept-ranges": "bytes", "cache-control": "no-store" };
    if (range) {
      const m = range.match(/bytes=(\d*)-(\d*)/);
      const start = m && m[1] ? Number(m[1]) : 0;
      const end = m && m[2] ? Math.min(Number(m[2]), size - 1) : size - 1;
      const chunk = fs.createReadStream(abs, { start, end });
      return new Response(chunk, { status: 206, headers: { ...headers, "content-range": `bytes ${start}-${end}/${size}`, "content-length": String(end - start + 1) } });
    }
    return new Response(fs.createReadStream(abs), { headers: { ...headers, "content-length": String(size) } });
  } catch {
    return new Response("허용되지 않은 경로", { status: 400 });
  }
}
