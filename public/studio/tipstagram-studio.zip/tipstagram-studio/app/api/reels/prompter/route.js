import fs from "node:fs";
import path from "node:path";
import { safeOutputPath, readJson } from "@/lib/store";
import { lanUrl } from "@/lib/reels/reference";
export const dynamic = "force-dynamic";

/** ?dir=… → 대본(할 말) + 같은 와이파이용 주소 + QR */
export async function GET(req) {
  try {
    const u = new URL(req.url);
    const rel = u.searchParams.get("dir") || "";
    const dir = safeOutputPath(rel);
    const s = readJson(path.join(dir, "대본.json"), null);
    if (!s?.scenes?.length) return Response.json({ message: "대본이 없어요." }, { status: 404 });
    const port = Number(u.port || process.env.STUDIO_PORT || 3777);
    const phoneUrl = lanUrl(port, `/reels/prompter?dir=${encodeURIComponent(rel)}`);
    let qr = null;
    if (phoneUrl) {
      const { default: QRCode } = await import("qrcode");
      qr = await QRCode.toDataURL(phoneUrl, { margin: 1, width: 220 });
    }
    const lines = s.scenes.map((sc) => sc.say || sc.caption).filter(Boolean);
    return Response.json({ lines, hooks: s.hooks || [], phoneUrl, qr });
  } catch (e) {
    return Response.json({ message: e.message }, { status: 500 });
  }
}
