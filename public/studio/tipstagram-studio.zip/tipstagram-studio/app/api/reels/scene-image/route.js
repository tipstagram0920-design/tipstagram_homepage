import path from "node:path";
import { safeOutputPath, OUTPUT_DIR } from "@/lib/store";
import { drawScene } from "@/lib/reels/images";
import { hasGemini } from "@/lib/reels/gemini";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

/**
 * 장면 **하나만** 다시 그리기. body: { dir, index, scene, fromLine? }
 * fromLine 이 false 가 아니면 그 장면의 대사에 맞춰 그림 설명을 새로 만든다.
 */
export async function POST(req) {
  try {
    if (!hasGemini()) return Response.json({ message: "Gemini 가 연결돼 있어야 그림을 다시 만들 수 있어요. 설정에서 연결해 주세요." }, { status: 400 });
    const { dir, index, scene, fromLine } = await req.json();
    if (!scene || typeof scene !== "object") {
      return Response.json({ message: "어느 장면인지 알 수 없어요. 화면을 새로 고치고 다시 눌러 주세요." }, { status: 400 });
    }
    const abs = safeOutputPath(dir);
    const file = path.join(abs, "images", `scene-${String(Number(index) + 1).padStart(2, "0")}.png`);
    const r = await drawScene(scene, file, { maxTries: 3, fromLine: fromLine !== false });
    if (!r.ok) return Response.json({ message: `이 장면은 아직 안 됐어요 (${r.reason}). 장면 설명을 조금 바꿔 보세요.` }, { status: 500 });
    const rel = path.relative(OUTPUT_DIR, file);
    return Response.json({ image: rel, url: `/api/output?p=${encodeURIComponent(rel)}&v=${Date.now()}` });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message }, { status: 500 });
  }
}
