import fs from "node:fs";
import path from "node:path";
import { newReelDir } from "@/lib/reels/index";
import { OUTPUT_DIR } from "@/lib/store";
export const dynamic = "force-dynamic";

/** multipart: photos[] (3~5장) → 작업 폴더에 저장 */
export async function POST(req) {
  try {
    const fd = await req.formData();
    const files = fd.getAll("photos").filter((f) => f && typeof f === "object" && f.size > 0);
    if (files.length < 1) return Response.json({ message: "사진을 골라 주세요." }, { status: 400 });
    if (files.length > 8) return Response.json({ message: "사진은 8장까지만 올릴 수 있어요." }, { status: 400 });
    const dir = newReelDir("사진릴스");
    const photoDir = path.join(dir, "photos");
    fs.mkdirSync(photoDir);
    const saved = [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (f.size > 25 * 1024 * 1024) return Response.json({ message: `${i + 1}번 사진이 너무 커요 (25MB 아래로).` }, { status: 400 });
      const ext = f.type === "image/png" ? "png" : f.type === "image/webp" ? "webp" : "jpg";
      const file = path.join(photoDir, `${String(i + 1).padStart(2, "0")}.${ext}`);
      fs.writeFileSync(file, Buffer.from(await f.arrayBuffer()));
      saved.push(path.relative(OUTPUT_DIR, file));
    }
    return Response.json({ dir: path.relative(OUTPUT_DIR, dir), photos: saved, urls: saved.map((p) => `/api/output?p=${encodeURIComponent(p)}`) });
  } catch (e) {
    return Response.json({ message: "사진을 저장하지 못했어요: " + e.message }, { status: 500 });
  }
}
