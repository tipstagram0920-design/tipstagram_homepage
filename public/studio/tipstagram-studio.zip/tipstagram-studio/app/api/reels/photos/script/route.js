import { getBrand, safeOutputPath } from "@/lib/store";
import { generateScript } from "@/lib/reels/script";
import { describePhotos } from "@/lib/reels/photos";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** body: { dir, photos:[rel], line, conditions? } → 대본 (구조 F 공구·제품 / C 비포·애프터) */
export async function POST(req) {
  try {
    const { dir, photos, line, conditions, experience } = await req.json();
    if (!photos?.length) return Response.json({ message: "사진이 없어요." }, { status: 400 });
    if (!String(line || "").trim()) return Response.json({ message: "제품이나 주제를 한 줄 적어 주세요." }, { status: 400 });
    const brand = getBrand();
    const abs = photos.map((p) => safeOutputPath(p));
    const desc = await describePhotos(abs);
    const isDeal = Boolean(String(conditions || "").trim());
    const source = `【제품/주제】 ${String(line).slice(0, 200)}
${isDeal ? `【공구 조건 (확정된 것만, 없는 내용은 지어내지 않는다)】 ${String(conditions).slice(0, 300)}` : "【공구 조건】 없음 → 가격·기간·혜택을 말하지 않는다. 비포→애프터나 사용 장면 중심으로."}
【써본 소감 (사용자가 직접 적은 것)】 ${String(experience || "").trim() ? String(experience).slice(0, 600) : "없음 → 몸의 변화·효과·후기를 말하지 않는다. 사진에서 보이는 사실(모양·색·포장·구성)과 '이런 분께'만 말한다."}
【사진 ${abs.length}장】 ${desc.length ? desc.map((d, i) => `\n${i + 1}. ${d}`).join("") : "(설명 없음 — 사진 순서대로 장면에 쓴다)"}
규칙: 장면 수는 사진 수와 같거나 많아도 된다(사진을 돌려 쓴다). **써본 소감에 적힌 경험만** 쓴다. 적히지 않은 효과·후기·인증·"2주 먹어봤더니" 같은 체험은 절대 지어내지 않는다. 건강·뷰티는 단정 금지. 광고 표기("협찬/공구 수수료를 받습니다")를 캡션 끝에 넣는다.`;
    const script = await generateScript({ brand, source, structure: isDeal ? "F" : "C", allowedStructures: ["F", "C"] });
    return Response.json({ script, presetId: 4, descriptions: desc });
  } catch (e) {
    return Response.json({ message: e.friendly || e.message, detail: e.detail }, { status: 500 });
  }
}
