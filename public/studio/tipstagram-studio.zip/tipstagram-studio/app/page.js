"use client";
import { useState } from "react";
import Link from "next/link";

export default function Home() {
  const [state, setState] = useState("idle"); // idle | loading | ok | error
  const [text, setText] = useState("");

  async function testClaude() {
    setState("loading");
    setText("");
    try {
      const r = await fetch("/api/claude/test", { method: "POST" });
      const j = await r.json();
      if (!r.ok) throw new Error(j.message || "실패");
      setText(j.text);
      setState("ok");
    } catch (e) {
      setText(e.message);
      setState("error");
    }
  }

  return (
    <>
      <h1>팁스타그램 수익화 스튜디오</h1>
      <p className="sub">내 컴퓨터에서 돌아가는 콘텐츠 제작 도구예요. 하고 싶은 일을 누르세요.</p>

      <Link href="/brand" className="bigbtn">
        <div className="icon">🎨</div>
        <div>
          <div className="label">브랜드 설정</div>
          <div className="desc">계정 이름, 로고, 색, 말투를 한 번만 적어두면 모든 콘텐츠에 적용돼요</div>
        </div>
      </Link>
      <Link href="/magazine" className="bigbtn">
        <div className="icon">📰</div>
        <div>
          <div className="label">매거진 콘텐츠 만들기</div>
          <div className="desc">소재 고르기 → 스타일 고르기 → 카드뉴스 완성 (3단계)</div>
        </div>
      </Link>
      <Link href="/reels" className="bigbtn">
        <div className="icon">🎬</div>
        <div>
          <div className="label">릴스 만들기</div>
          <div className="desc">카드뉴스로 · 레퍼런스 따라찍기 · 사진으로 (단계별로 열려요)</div>
        </div>
      </Link>
      <Link href="/library" className="bigbtn" style={{ padding: "18px 28px" }}>
        <div className="icon" style={{ width: 52, height: 52, fontSize: 26, background: "#EEF2FB" }}>📁</div>
        <div>
          <div className="label" style={{ fontSize: 22 }}>내가 만든 것 보기</div>
          <div className="desc">카드뉴스·릴스 전부 한 곳에서 보고, 지우고, 릴스로 만들기</div>
        </div>
      </Link>
      <div className="muted" style={{ textAlign: "center", marginTop: 4 }}>
        <Link href="/settings" style={{ textDecoration: "underline" }}>⚙️ 설정 (Gemini 연결 · 내 스타일)</Link>
      </div>

      <div className="card" style={{ marginTop: 30 }}>
        <h2>클로드 연결 확인</h2>
        <p className="muted" style={{ marginTop: 0 }}>
          이 버튼은 클로드에게 &quot;인스타 카드뉴스 제목 3개 만들어줘&quot;라고 물어봐요. 답이 오면 준비가 다 된 거예요.
        </p>
        <button className="btn primary block" onClick={testClaude} disabled={state === "loading"}>
          {state === "loading" ? (<><span className="spinner" /> 클로드가 생각하는 중이에요… (20초쯤 걸려요)</>) : "클로드에게 물어보기"}
        </button>
        {state === "ok" && (
          <div className="notice ok">
            <strong>연결됐어요! 클로드의 답:</strong>
            <pre className="pre" style={{ marginTop: 10 }}>{text}</pre>
          </div>
        )}
        {state === "error" && (
          <div className="notice warn">
            <strong>아직 연결이 안 됐어요.</strong>
            <div style={{ marginTop: 8 }}>{text}</div>
          </div>
        )}
      </div>
    </>
  );
}
