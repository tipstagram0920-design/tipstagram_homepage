"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import ProgressBar from "@/components/ProgressBar";

async function post(url, body) {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || "문제가 생겼어요. 다시 눌러 주세요.");
  return j;
}

export default function ReferencePage() {
  const [step, setStep] = useState(1);
  const [gemini, setGemini] = useState(null);
  const [busy, setBusy] = useState(""); // 진행 라벨
  const [pct, setPct] = useState(null);  // 실제 %가 있을 때(업로드)
  const [est, setEst] = useState(60000);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(null);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [url, setUrl] = useState("");
  const [text, setText] = useState("");
  const [fetchFailed, setFetchFailed] = useState("");
  const [dir, setDir] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [topicHint, setTopicHint] = useState("");
  const [result, setResult] = useState(null); // {script, presetName}
  const [hookIdx, setHookIdx] = useState(0);

  useEffect(() => { fetch("/api/settings/gemini").then((r) => r.json()).then((g) => setGemini(Boolean(g.connected))).catch(() => setGemini(false)); }, []);
  function flash(t) { setToast(t); setTimeout(() => setToast(""), 2500); }

  async function analyzeFile(relDir, relFile) {
    setBusy("영상을 읽고 있어요 (말한 내용·장면·훅을 뽑는 중)"); setPct(null); setEst(45000);
    try {
      const j = await post("/api/reels/reference/analyze", { dir: relDir, file: relFile });
      setDir(j.dir); setAnalysis(j.analysis); setStep(2); window.scrollTo(0, 0);
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  async function fromUrl() {
    setError(""); setFetchFailed(""); setBusy("릴스를 가져오는 중이에요…");
    try {
      const j = await post("/api/reels/reference/fetch", { url });
      if (j.failed) { setFetchFailed(j.reason); setDir(j.dir || null); setBusy(""); return; }
      setDir(j.dir);
      await analyzeFile(j.dir, j.file);
    } catch (e) { setError(e.message); setBusy(""); }
  }

  async function fromFile(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    setError(""); setBusy("영상을 올리는 중"); setPct(0);
    try {
      const fd = new FormData(); fd.append("video", f); if (dir) fd.append("dir", dir);
      const j = await new Promise((resolve, reject) => {
        const x = new XMLHttpRequest();
        x.open("POST", "/api/reels/reference/upload");
        x.upload.onprogress = (ev) => ev.lengthComputable && setPct(Math.round((ev.loaded / ev.total) * 100));
        x.onload = () => { try { const r = JSON.parse(x.responseText); x.status < 300 ? resolve(r) : reject(new Error(r.message || "올리지 못했어요")); } catch { reject(new Error("올리지 못했어요")); } };
        x.onerror = () => reject(new Error("올리지 못했어요. 인터넷을 확인해 주세요."));
        x.send(fd);
      });
      setDir(j.dir);
      await analyzeFile(j.dir, j.file);
    } catch (err) { setError(err.message); setBusy(""); } finally { e.target.value = ""; }
  }

  async function fromText() {
    setError(""); setBusy("글을 읽고 있어요"); setPct(null); setEst(30000);
    try {
      const j = await post("/api/reels/reference/analyze", { dir, text });
      setDir(j.dir); setAnalysis(j.analysis); setStep(2); window.scrollTo(0, 0);
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  async function makeScript(hook = "") {
    setError(""); setBusy("내 대본을 쓰고 있어요 (말 전체를 먼저 쓰고 장면으로 나눠요)"); setPct(null); setEst(45000);
    try {
      const j = await post("/api/reels/reference/script", { dir, analysis, hook, topicHint });
      setResult(j); setHookIdx(0); setEditing(false); setDraft(null); setStep(3); window.scrollTo(0, 0);
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  async function likeScript() {
    const sc = (typeof script !== "undefined" && script) ? script : (result?.script || null);
    if (!sc) return;
    const text = sc.scenes.map((x) => x.say || x.caption).join("\n");
    try { await post("/api/settings/my-style", { like: text }); flash("내 대본 샘플에 넣었어요. 다음 대본부터 이 말투를 참고해요."); } catch (e) { setError(e.message); }
  }
  function startEdit() { setDraft(JSON.parse(JSON.stringify(result.script))); setEditing(true); }
  function editScene(i, k, v) { setDraft((d) => { const sc = [...d.scenes]; sc[i] = { ...sc[i], [k]: v }; return { ...d, scenes: sc }; }); }
  function removeScene(i) { setDraft((d) => ({ ...d, scenes: d.scenes.filter((_, k) => k !== i) })); }
  function addScene(i) { setDraft((d) => { const sc = [...d.scenes]; sc.splice(i + 1, 0, { seconds: 3, caption: "", say: "", shoot: "카메라 보고 말하기", emphasis: "" }); return { ...d, scenes: sc }; }); }
  async function saveEdit() {
    setError(""); setBusy("고친 대본을 저장하고 있어요"); setPct(null); setEst(3000);
    try {
      const j = await post("/api/reels/reference/save", { dir, script: draft });
      setResult({ ...result, script: j.script }); setEditing(false); flash("저장했어요. 프롬프터와 촬영가이드에도 반영됐어요.");
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  async function copy(t, msg) { try { await navigator.clipboard.writeText(t); flash(msg); } catch { setError("복사가 안 됐어요. 글을 직접 드래그해서 복사해 주세요."); } }
  async function openFolder() { try { await post("/api/open", { dir }); flash("폴더를 열었어요"); } catch (e) { setError(e.message); } }

  const s = result?.script;

  return (
    <>
      <div className="topbar">
        <Link href="/reels" className="back">← 릴스 만들기</Link>
        {step > 1 && !busy && <button className="btn ghost small" onClick={() => setStep(step - 1)}>이전 단계</button>}
      </div>
      <h1>레퍼런스 따라찍기</h1>
      <div className="steps">
        <span className={step === 1 ? "on" : "done"}>1. 레퍼런스 넣기</span>
        <span className={step === 2 ? "on" : step > 2 ? "done" : ""}>2. 잘된 이유</span>
        <span className={step === 3 ? "on" : ""}>3. 내 대본·촬영</span>
      </div>
      {error && <div className="notice warn">{error}</div>}
      {busy && <ProgressBar label={busy} percent={pct} estimateMs={est} />}
      {toast && <div className="notice ok">{toast}</div>}

      {step === 1 && (
        <>
          <p className="sub">잘된 릴스를 넣으면 구조를 읽어서 내 분야 대본과 촬영 가이드를 만들어요.</p>
          {gemini === false && (
            <div className="notice info">Gemini 가 연결돼 있지 않아 영상은 읽을 수 없어요. 아래 "글로 붙여 넣기"를 쓰거나 <Link href="/settings" style={{ textDecoration: "underline" }}>설정</Link>에서 연결해 주세요.</div>
          )}
          {gemini && (
            <div className="card">
              <h2>① 릴스 주소 붙여 넣기</h2>
              <div className="row">
                <input type="text" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://www.instagram.com/reel/…" style={{ flex: 3 }} />
                <button className="btn" style={{ flex: 1 }} disabled={!url.trim() || !!busy} onClick={fromUrl}>가져오기</button>
              </div>
              {fetchFailed && (
                <div className="notice info" style={{ marginTop: 12 }}>
                  주소로는 못 가져왔어요 ({fetchFailed}). 괜찮아요, 아래처럼 하면 돼요: 인스타 앱에서 그 릴스의 <strong>⋯ → 저장(다운로드)</strong> 으로 영상을 받은 뒤, 아래 ②에서 올려 주세요.
                </div>
              )}
            </div>
          )}
          {gemini && (
            <div className="card">
              <h2>② 영상 파일 직접 올리기</h2>
              <div className="muted" style={{ marginBottom: 10 }}>mp4 · mov, 300MB 까지. 올리면 바로 읽기 시작해요.</div>
              <label className="btn ghost" style={{ cursor: busy ? "wait" : "pointer", opacity: busy ? 0.5 : 1 }}>{busy ? "읽는 중이에요…" : "영상 고르기"}<input type="file" accept="video/mp4,video/quicktime" style={{ display: "none" }} onChange={fromFile} disabled={!!busy} /></label>
            </div>
          )}
          <div className="card">
            <h2>{gemini ? "③" : "①"} 글로 붙여 넣기</h2>
            <div className="muted" style={{ marginBottom: 10 }}>영상이 없으면 레퍼런스의 캡션이나 받아 적은 대본을 붙여 넣어도 돼요. (구조만 읽어요)</div>
            <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="레퍼런스 릴스의 캡션 또는 말한 내용" style={{ minHeight: 140 }} />
            <button className="btn primary block" style={{ marginTop: 10 }} disabled={text.trim().length < 20 || !!busy} onClick={fromText}>이 글로 분석하기</button>
          </div>
        </>
      )}

      {step === 2 && analysis && (
        <>
          <p className="sub">이 릴스가 잘된 이유예요. 아래에서 내 대본으로 바꿔요.</p>
          <div className="card">
            <h2>잘된 이유</h2>
            <ol style={{ paddingLeft: 24, lineHeight: 1.8, fontSize: 21, margin: 0 }}>{analysis.whyItWorks.map((w, i) => <li key={i}>{w}</li>)}</ol>
          </div>
          <div className="card">
            <h2>구조</h2>
            <div style={{ lineHeight: 1.8 }}>
              <div>길이 <strong>{Math.round(analysis.totalSeconds)}초</strong> · 장면 <strong>{analysis.scenes.length}개</strong> · 속도 {analysis.pace}</div>
              <div>훅: <strong>{analysis.hookType}</strong> {analysis.hookText && <span className="muted">「{analysis.hookText}」</span>}</div>
              <div>마무리: {analysis.ending}</div>
            </div>
            {analysis.scenes.length > 0 && (
              <div style={{ marginTop: 12 }}>
                {analysis.scenes.map((sc, i) => <div key={i} className="muted" style={{ padding: "4px 0", borderTop: "1px solid var(--line)" }}>{i + 1}. {Math.round(sc.start)}~{Math.round(sc.end)}초 · {sc.what} <span style={{ color: "#999" }}>({sc.shot})</span></div>)}
              </div>
            )}
          </div>
          <div className="card">
            <label className="field" style={{ marginBottom: 12 }}>
              <span>이번 릴스 주제 (선택) <small>비우면 내 분야에서 레퍼런스와 같은 결로 골라요</small></span>
              <input type="text" value={topicHint} onChange={(e) => setTopicHint(e.target.value)} placeholder="예: 계단 내려올 때 무릎 아픈 분" />
            </label>
            <button className="btn primary block" onClick={() => makeScript("")} disabled={!!busy}>내 대본 만들기</button>
          </div>
        </>
      )}

      {step === 3 && s && (
        <>
          <p className="sub">구조는 레퍼런스대로, 내용은 내 것으로. 추천 프리셋: {result.presetName}</p>
          <div className="card">
            <h2>훅 — 첫 3초</h2>
            <div className="muted" style={{ marginBottom: 8 }}>다른 훅을 고르면 그 훅으로 대본을 다시 써요.</div>
            {s.hooks.map((h, i) => (
              <div key={i} className={`card selectable ${hookIdx === i ? "selected" : ""}`} style={{ padding: 14, marginBottom: 8 }} onClick={() => { if (i !== hookIdx && !busy) { setHookIdx(i); makeScript(h.text); } }}>
                {h.formula && <span className="badge">{h.formula}</span>}
                <div style={{ fontSize: 23, fontWeight: 800 }}>{h.text}</div>
              </div>
            ))}
          </div>
          {s.narration && (
            <div className="card">
              <h2>말 전체 (한 호흡으로 읽어보세요)</h2>
              <pre className="pre" style={{ fontSize: 20 }}>{s.narration}</pre>
            </div>
          )}
          <div className="card">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
              <h2 style={{ margin: 0 }}>장면별 촬영 가이드</h2>
              {!editing ? <button className="btn ghost small" onClick={startEdit}>✏️ 대본 고치기</button> : (
                <div className="row"><button className="btn primary small" onClick={saveEdit} disabled={!!busy}>저장</button><button className="btn ghost small" onClick={() => setEditing(false)}>취소</button></div>
              )}
            </div>
            {editing && draft ? draft.scenes.map((sc, i) => (
              <div key={i} className="edit-scene">
                <div><div style={{ fontSize: 22, fontWeight: 800 }}>{i + 1}</div><input type="text" value={sc.seconds} onChange={(e) => editScene(i, "seconds", e.target.value)} style={{ width: 56, padding: 6 }} /><div className="muted" style={{ fontSize: 13 }}>초</div></div>
                <div>
                  <textarea value={sc.say} onChange={(e) => editScene(i, "say", e.target.value)} placeholder="🗣 할 말" />
                  <input type="text" value={sc.shoot} onChange={(e) => editScene(i, "shoot", e.target.value)} placeholder="🎥 무엇을 찍을지" />
                  <input type="text" value={sc.caption} onChange={(e) => editScene(i, "caption", e.target.value)} placeholder="화면 글자 (12자×2줄)" />
                  <div className="row"><button className="btn ghost small" onClick={() => addScene(i)}>아래에 장면 추가</button><button className="btn ghost small" onClick={() => removeScene(i)} disabled={draft.scenes.length <= 2}>이 장면 빼기</button></div>
                </div>
              </div>
            )) : s.scenes.map((sc, i) => (
              <div key={i} style={{ padding: "14px 0", borderTop: i ? "2px solid var(--line)" : "none", display: "grid", gridTemplateColumns: "70px 1fr", gap: 10 }}>
                <div><div style={{ fontSize: 22, fontWeight: 800 }}>{sc.scene}</div><div className="muted">{sc.seconds}초</div></div>
                <div>
                  <div style={{ fontSize: 18 }}>🎥 {sc.shoot}</div>
                  <div style={{ fontSize: 21, fontWeight: 700, margin: "4px 0" }}>🗣 {sc.say}</div>
                  <div className="muted">화면 글자: {sc.caption}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="card">
            <h2>캡션</h2>
            <pre className="pre">{s.caption}</pre>
            <div style={{ marginTop: 10, color: "var(--accent-ink)", fontWeight: 600 }}>{s.hashtags.join(" ")}</div>
          </div>
          <div className="actions">
            <Link href={`/reels/prompter?dir=${encodeURIComponent(dir)}`} className="btn primary primary-action">📱 프롬프터 열고 촬영하기</Link>
            <div className="actions-grid">
              <button className="btn" onClick={() => copy(s.scenes.map((sc) => `[${sc.scene}] ${sc.say}`).join("\n"), "대본을 복사했어요")}>대본 복사</button>
              <button className="btn" onClick={() => copy(`${s.caption}\n\n${s.hashtags.join(" ")}`, "캡션을 복사했어요")}>캡션 복사</button>
              <button className="btn ghost" onClick={likeScript}>👍 대본 좋아요</button>
              <button className="btn ghost" onClick={openFolder}>📂 폴더 열기</button>
            </div>
            <div className="actions-grid" style={{ marginTop: 10, gridTemplateColumns: "1fr" }}>
              <button className="btn ghost" onClick={() => makeScript(s.hooks[hookIdx]?.text || "")} disabled={!!busy}>🔄 마음에 안 들면 대본 다시 쓰기</button>
            </div>
            <div className="actions-note">촬영가이드.md · 대본.json · 캡션.txt 로 저장됐어요. 건강·돈 이야기는 올리기 전에 내용이 맞는지 한 번 확인해 주세요.</div>
          </div>
        </>
      )}
    </>
  );
}
