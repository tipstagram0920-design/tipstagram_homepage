"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";

const SPEEDS = { slow: 28, normal: 45, fast: 70 }; // px/초

function Prompter() {
  const params = useSearchParams();
  const dir = params.get("dir") || "";
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [speed, setSpeed] = useState("normal");
  const [running, setRunning] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const scroller = useRef(null);
  const raf = useRef(null);

  useEffect(() => {
    fetch(`/api/reels/prompter?dir=${encodeURIComponent(dir)}`).then((r) => r.json()).then((j) => (j.message ? setError(j.message) : setData(j))).catch(() => setError("대본을 불러오지 못했어요."));
  }, [dir]);

  useEffect(() => {
    if (!running) { cancelAnimationFrame(raf.current); return; }
    let last = performance.now();
    const tick = (now) => {
      const el = scroller.current;
      if (el) {
        el.scrollTop += (SPEEDS[speed] * (now - last)) / 1000;
        if (el.scrollTop + el.clientHeight >= el.scrollHeight - 2) setRunning(false);
      }
      last = now;
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [running, speed]);

  function fullscreen() { const el = document.documentElement; (el.requestFullscreen || el.webkitRequestFullscreen)?.call(el); }
  function restart() { if (scroller.current) scroller.current.scrollTop = 0; setRunning(true); }

  return (
    <div className="prompter">
      <div className="prompter-bar">
        <a href={`/reels/reference`} className="pbtn">← 돌아가기</a>
        <button className={`pbtn ${speed === "slow" ? "on" : ""}`} onClick={() => setSpeed("slow")}>느리게</button>
        <button className={`pbtn ${speed === "normal" ? "on" : ""}`} onClick={() => setSpeed("normal")}>보통</button>
        <button className={`pbtn ${speed === "fast" ? "on" : ""}`} onClick={() => setSpeed("fast")}>빠르게</button>
        <button className="pbtn accent" onClick={() => (running ? setRunning(false) : restart())}>{running ? "멈춤" : "▶ 시작"}</button>
        <button className="pbtn" onClick={fullscreen}>전체 화면</button>
        {data?.qr && <button className="pbtn" onClick={() => setShowQr(!showQr)}>📱 폰으로</button>}
      </div>
      {showQr && data?.qr && (
        <div className="prompter-qr">
          <img src={data.qr} alt="QR" />
          <div>같은 와이파이에서 폰 카메라로 찍으면 폰에서 열려요<br /><span style={{ opacity: 0.7 }}>{data.phoneUrl}</span></div>
        </div>
      )}
      {error && <div className="prompter-text" style={{ fontSize: 28 }}>{error}</div>}
      <div className="prompter-scroll" ref={scroller} onClick={() => (running ? setRunning(false) : setRunning(true))}>
        <div style={{ height: "45vh" }} />
        {data?.lines.map((l, i) => <p key={i} className="prompter-text">{l}</p>)}
        <div style={{ height: "60vh" }} />
      </div>
    </div>
  );
}

export default function Page() {
  return <Suspense fallback={null}><Prompter /></Suspense>;
}
