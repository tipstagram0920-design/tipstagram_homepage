"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";

const BGMS = [
  { id: "bright", name: "밝게", desc: "제품·일상" },
  { id: "calm", name: "잔잔하게", desc: "정보·설명" },
  { id: "tension", name: "긴장감", desc: "센 훅·순위" },
  { id: "none", name: "음악 없이", desc: "" },
];
async function post(url, body) {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || "문제가 생겼어요. 다시 눌러 주세요.");
  return j;
}

export default function PhotosReel() {
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [files, setFiles] = useState([]); // File[]
  const [previews, setPreviews] = useState([]);
  const [line, setLine] = useState("");
  const [conditions, setConditions] = useState("");
  const [experience, setExperience] = useState("");
  const [upload, setUpload] = useState(null); // {dir, photos}
  const [script, setScript] = useState(null);
  const [hookIdx, setHookIdx] = useState(0);
  const [bgm, setBgm] = useState("bright");
  const [job, setJob] = useState(null);
  const pollRef = useRef(null);
  useEffect(() => () => clearInterval(pollRef.current), []);
  function flash(t) { setToast(t); setTimeout(() => setToast(""), 2500); }

  function pick(e) {
    const list = Array.from(e.target.files || []).slice(0, 8);
    setFiles(list); setPreviews(list.map((f) => URL.createObjectURL(f)));
  }
  function remove(i) { const f = files.filter((_, k) => k !== i); setFiles(f); setPreviews(f.map((x) => URL.createObjectURL(x))); }

  async function writeScript() {
    setError(""); setBusy("사진을 올리고 대본을 쓰고 있어요… (40초쯤 걸려요)");
    try {
      const fd = new FormData(); files.forEach((f) => fd.append("photos", f));
      const r = await fetch("/api/reels/photos/upload", { method: "POST", body: fd });
      const up = await r.json(); if (!r.ok) throw new Error(up.message);
      setUpload(up);
      const j = await post("/api/reels/photos/script", { dir: up.dir, photos: up.photos, line, conditions, experience });
      setScript(j.script); setHookIdx(0); setStep(2); window.scrollTo(0, 0);
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  function scenesWithHook() {
    const s = script.scenes.map((x) => ({ ...x }));
    const h = script.hooks[hookIdx]?.text;
    if (h) { s[0].caption = h; if (s[0].emphasis && !h.includes(s[0].emphasis)) s[0].emphasis = ""; }
    return s;
  }

  async function make() {
    setError(""); setStep(4); setJob({ stage: "준비 중", progress: "" });
    try {
      const endCard = conditions.trim() ? conditions.split(/\n|,|·/).map((x) => x.trim()).filter(Boolean).slice(0, 4) : undefined;
      const { id } = await post("/api/reels/jobs", { photoMode: true, script: { ...script, scenes: scenesWithHook() }, presetId: 4, bgm, images: upload.photos, dir: upload.dir, endCard, label: `사진릴스_${line}` });
      clearInterval(pollRef.current);
      pollRef.current = setInterval(async () => {
        try { const r = await fetch(`/api/reels/jobs/${id}`); const j = await r.json(); setJob(j); if (j.done) { clearInterval(pollRef.current); if (j.error) setError(j.error); } } catch {}
      }, 1500);
    } catch (e) { setError(e.message); }
  }

  async function likeScript() {
    const sc = (typeof script !== "undefined" && script) ? script : (result?.script || null);
    if (!sc) return;
    const text = sc.scenes.map((x) => x.say || x.caption).join("\n");
    try { await post("/api/settings/my-style", { like: text }); flash("내 대본 샘플에 넣었어요. 다음 대본부터 이 말투를 참고해요."); } catch (e) { setError(e.message); }
  }
  async function copyCaption() { try { await navigator.clipboard.writeText(`${script.caption}\n\n${script.hashtags.join(" ")}`); flash("캡션을 복사했어요"); } catch { setError("복사가 안 됐어요."); } }
  async function openFolder() { try { await post("/api/open", { dir: job.result.dir }); flash("폴더를 열었어요"); } catch (e) { setError(e.message); } }

  return (
    <>
      <div className="topbar">
        <Link href="/reels" className="back">← 릴스 만들기</Link>
        {step > 1 && step < 4 && !busy && <button className="btn ghost small" onClick={() => setStep(step - 1)}>이전 단계</button>}
      </div>
      <h1>사진으로 릴스 만들기</h1>
      <div className="steps">
        <span className={step === 1 ? "on" : "done"}>1. 사진·한 줄</span>
        <span className={step === 2 ? "on" : step > 2 ? "done" : ""}>2. 훅 고르기</span>
        <span className={step === 3 ? "on" : step > 3 ? "done" : ""}>3. 음악</span>
        <span className={step === 4 ? "on" : ""}>4. 완성</span>
      </div>
      {error && <div className="notice warn">{error}</div>}
      {busy && <div className="notice info"><span className="spinner" />{busy}</div>}
      {toast && <div className="notice ok">{toast}</div>}

      {step === 1 && (
        <>
          <p className="sub">사진 3~5장과 한 줄만 있으면 돼요. 사진은 그대로 쓰고(그림 생성 없음) 자막·음악을 붙여요.</p>
          <div className="card">
            <h2>사진 3~5장</h2>
            <label className="btn ghost" style={{ cursor: "pointer" }}>사진 고르기<input type="file" accept="image/png,image/jpeg,image/webp" multiple style={{ display: "none" }} onChange={pick} /></label>
            {previews.length > 0 && (
              <div className="scenes" style={{ marginTop: 14 }}>
                {previews.map((src, i) => (
                  <div key={i} className="scene">
                    <div className="thumb" style={{ aspectRatio: "9/16" }}><img src={src} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /></div>
                    <button className="btn ghost small" style={{ width: "100%", marginTop: 6 }} onClick={() => remove(i)}>빼기</button>
                  </div>
                ))}
              </div>
            )}
            <div className="muted" style={{ marginTop: 8 }}>{files.length}장 골랐어요. 첫 사진이 첫 장면이에요.</div>
          </div>
          <div className="card">
            <label className="field"><span>제품 또는 주제 한 줄</span><input type="text" value={line} onChange={(e) => setLine(e.target.value)} placeholder="예: 50대 무릎 보호대 공구 / 우리 집 베란다 텃밭 3주 변화" /></label>
            <label className="field"><span>써본 소감 (선택) <small>직접 써보고 느낀 것만 적어 주세요. 안 적으면 효과·후기는 말하지 않고 사진에 보이는 것만 말해요.</small></span>
              <textarea value={experience} onChange={(e) => setExperience(e.target.value)} placeholder="예: 2주 먹어보니 아침이 편해졌어요. 단맛이 세지 않아서 좋았고, 씹는 맛이 꾸덕해요." style={{ minHeight: 80 }} /></label>
            <label className="field"><span>공구 조건 (공구일 때만) <small>확정된 기간·혜택만. 비우면 비포→애프터 식으로 만들어요. 줄바꿈이나 쉼표로 나누면 마지막 카드에 그대로 떠요.</small></span>
              <textarea value={conditions} onChange={(e) => setConditions(e.target.value)} placeholder={"예: 10월 20일~24일\n공구가 20% 할인\n댓글에 '보호대' 남기면 링크"} style={{ minHeight: 90 }} /></label>
            <button className="btn primary block" disabled={files.length < 1 || !line.trim() || !!busy} onClick={writeScript}>대본 만들기</button>
          </div>
        </>
      )}

      {step === 2 && script && (
        <>
          <p className="sub">첫 3초에 나올 말을 고르세요.</p>
          <div className="optgrid" style={{ gridTemplateColumns: "1fr" }}>
            {script.hooks.map((h, i) => (
              <div key={i} className={`opt ${hookIdx === i ? "on" : ""}`} onClick={() => setHookIdx(i)}>
                <div className="opt-body">{h.formula && <span className="badge">{h.formula}</span>}<div className="opt-title" style={{ fontSize: 24 }}>{h.text}</div></div>
              </div>
            ))}
          </div>
          <div className="card" style={{ background: "#FAFAF8" }}>
            <div className="muted" style={{ marginBottom: 8 }}>대본 미리보기 ({script.scenes.length}장면 · 약 {Math.round(script.scenes.reduce((a, s) => a + s.seconds, 0))}초 · {script.structure === "F" ? "공구·제품" : "비포→애프터"} 구조)</div>
            {scenesWithHook().map((s, i) => <div key={i} style={{ padding: "6px 0", borderTop: i ? "1px solid var(--line)" : "none" }}><span className="muted">{i + 1}.</span> {s.caption}</div>)}
          </div>
          <button className="btn primary block" onClick={() => { setStep(3); window.scrollTo(0, 0); }}>이 훅으로 할게요</button>
        </>
      )}

      {step === 3 && (
        <>
          <div className="section">
            <h2>배경음악</h2>
            <div className="section-sub">영상 분위기에 맞는 음악을 고르세요.</div>
            <div className="optgrid">
              {BGMS.map((b) => (
                <div key={b.id} className={`opt ${bgm === b.id ? "on" : ""}`} onClick={() => setBgm(b.id)}>
                  <div className="opt-body"><div className="opt-title">{b.name}</div>{b.desc && <div className="opt-desc">{b.desc}</div>}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="section"><button className="btn primary block" onClick={make}>영상 만들기</button></div>
        </>
      )}

      {step === 4 && (
        <>
          {job && !job.done && (
            <div className="card" style={{ textAlign: "center", padding: 40 }}>
              <span className="spinner" style={{ width: 40, height: 40 }} />
              <div style={{ fontSize: 24, fontWeight: 800, marginTop: 14 }}>{job.stage}</div>
              <div className="muted">{job.progress || "조금만 기다려 주세요."}</div>
            </div>
          )}
          {job?.done && job.result && (
            <>
              <p className="sub">완성됐어요. {Math.round(job.result.seconds)}초 영상이에요.</p>
              <div className="phone" style={{ maxWidth: 320 }}><div className="screen" style={{ aspectRatio: "9/16" }}><video src={job.result.videoUrl} controls playsInline style={{ width: "100%", height: "100%", background: "#000" }} /></div></div>
              <div className="card"><h2>캡션</h2><pre className="pre">{script.caption}</pre><div style={{ marginTop: 12, color: "var(--accent-ink)", fontWeight: 600 }}>{script.hashtags.join(" ")}</div></div>
              <div className="actions">
                <button className="btn primary primary-action" onClick={openFolder}>📂 영상 폴더 열기 (인스타에 올리기)</button>
                <div className="actions-grid">
                  <button className="btn" onClick={copyCaption}>캡션 복사</button>
                  <button className="btn ghost" onClick={likeScript}>👍 대본 좋아요</button>
                  <button className="btn ghost" onClick={() => { setStep(2); setJob(null); }}>훅부터 다시</button>
                </div>
                <div className="actions-note">저장 위치: {job.result.absDir}</div>
              </div>
            </>
          )}
        </>
      )}
    </>
  );
}
