"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import VoicePreview from "@/components/VoicePreview";

const BGMS = [
  { id: "calm", name: "잔잔하게", desc: "정보·설명 영상" },
  { id: "bright", name: "밝게", desc: "제품·일상" },
  { id: "tension", name: "긴장감", desc: "센 훅·순위" },
  { id: "none", name: "음악 없이", desc: "" },
];

async function post(url, body) {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || "문제가 생겼어요. 다시 눌러 주세요.");
  return j;
}

function CardnewsToReel() {
  const params = useSearchParams();
  const preDir = params.get("dir");
  const [step, setStep] = useState(1);
  const [sets, setSets] = useState([]);
  const [picked, setPicked] = useState(null);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [script, setScript] = useState(null);
  const [presetId, setPresetId] = useState(1);
  const [hookIdx, setHookIdx] = useState(0);
  const [bgm, setBgm] = useState("bright");
  const [voices, setVoices] = useState([]);
  const [voiceId, setVoiceId] = useState("Kore");
  const [playing, setPlaying] = useState("");
  const [job, setJob] = useState(null);
  const [gemini, setGemini] = useState(null); // null=모름, true/false
  const pollRef = useRef(null);

  useEffect(() => {
    (async () => {
      let connected = false;
      try { const g = await (await fetch("/api/settings/gemini")).json(); connected = Boolean(g.connected); } catch {}
      setGemini(connected);
      try { const v = await (await fetch("/api/reels/voice-sample")).json(); setVoices(v.voices || []); } catch {}
      const j = await (await fetch("/api/reels/cardnews-list")).json();
      setSets(j.sets || []);
      if (preDir) { const s = (j.sets || []).find((x) => x.dir === preDir); if (s) choose(s, connected); }
    })();
    return () => clearInterval(pollRef.current);
  }, []);

  function flash(t) { setToast(t); setTimeout(() => setToast(""), 2500); }

  async function choose(set, connected = gemini) {
    setPicked(set); setError(""); setScript(null); setJob(null);
    if (!connected) { setStep(3); window.scrollTo(0, 0); return; } // 슬라이드 모드: 카드 그대로, 자막·대본 없음
    setBusy("대본 쓰는 중이에요… (30초쯤 걸려요)");
    try {
      const j = await post("/api/reels/script", { source: { kind: "cardnews", dir: set.dir } });
      setScript(j.script); setPresetId(j.presetId); setHookIdx(0);
      setStep(2); window.scrollTo(0, 0);
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  function scenesWithHook() {
    if (!script) return [];
    const s = script.scenes.map((x) => ({ ...x }));
    const h = script.hooks[hookIdx]?.text;
    if (h) { s[0].caption = h; if (s[0].emphasis && !h.includes(s[0].emphasis)) s[0].emphasis = ""; }
    return s;
  }

  async function make(extra = {}) {
    setError(""); setStep(4); setJob({ stage: "준비 중", progress: "" });
    try {
      const body = script
        ? { script: { ...script, scenes: scenesWithHook() }, presetId, bgm, voiceId, banner: { titleTop: script.titleTop, titleMain: script.titleMain }, source: { kind: "cardnews", dir: picked.dir }, label: `릴스_${picked.title}`, ...extra }
        : { slideMode: true, source: { kind: "cardnews", dir: picked.dir }, presetId, bgm, label: `릴스_${picked.title}` };
      const { id } = await post("/api/reels/jobs", body);
      clearInterval(pollRef.current);
      pollRef.current = setInterval(async () => {
        try {
          const r = await fetch(`/api/reels/jobs/${id}`); const j = await r.json();
          setJob(j);
          if (j.done) { clearInterval(pollRef.current); if (j.error) setError(j.error); }
        } catch {}
      }, 1500);
    } catch (e) { setError(e.message); }
  }

  function playSample(id) {
    if (playing === id) { setPlaying(""); return; }
    setPlaying(id);
    const a = new Audio(`/api/reels/voice-sample?voice=${id}`);
    a.onended = () => setPlaying(""); a.onerror = () => { setPlaying(""); setError("미리듣기를 만들지 못했어요. 잠시 뒤 다시 눌러 주세요."); };
    a.play().catch(() => setPlaying(""));
  }

  async function uploadSceneImage(i, e) {
    const f = e.target.files?.[0];
    if (!f || !job?.result) return;
    setError(""); setBusy(`${i + 1}번 장면에 내 사진을 넣고 있어요…`);
    try {
      const fd = new FormData(); fd.append("dir", job.result.dir); fd.append("index", String(i)); fd.append("image", f);
      const r = await fetch("/api/reels/scene-upload", { method: "POST", body: fd });
      const j = await r.json(); if (!r.ok) throw new Error(j.message);
      const images = [...job.result.images]; images[i] = j.image;
      const fits = [...job.result.fits]; fits[i] = "cover";
      setJob({ ...job, result: { ...job.result, images, fits, failed: (job.result.failed || []).filter((f) => f.index !== i) } });
      flash("사진을 넣었어요. '이 그림들로 영상 다시 만들기'를 누르면 반영돼요.");
    } catch (err) { setError(err.message); } finally { setBusy(""); e.target.value = ""; }
  }

  /** 그 장면의 대사 — 결과에 남은 것이 1순위다 (화면 state 는 새로 고치면 사라진다) */
  function sceneAt(i) {
    return job?.result?.scenes?.[i] || scenesWithHook()[i] || null;
  }

  async function redrawScene(i) {
    if (!job?.result) return;
    const scene = sceneAt(i);
    if (!scene) { setError("어느 장면인지 알 수 없어요. 화면을 새로 고치고 다시 눌러 주세요."); return; }
    setError(""); setBusy(`${i + 1}번 장면을 대사에 맞춰 다시 그리고 있어요…`);
    try {
      // ★ 이 장면 하나만. 대사에 맞춰 새로 그린다.
      const r = await post("/api/reels/scene-image", { dir: job.result.dir, index: i, scene, fromLine: true });
      const images = [...job.result.images]; images[i] = r.image;
      const fits = [...job.result.fits]; fits[i] = "cover";
      setJob({ ...job, result: { ...job.result, images, fits, failed: job.result.failed.filter((f) => f.index !== i) } });
      flash("이 장면만 대사에 맞춰 다시 그렸어요. '이 그림들로 영상 다시 만들기'를 누르면 반영돼요.");
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  async function likeScript() {
    const sc = (typeof script !== "undefined" && script) ? script : (result?.script || null);
    if (!sc) return;
    const text = sc.scenes.map((x) => x.say || x.caption).join("\n");
    try { await post("/api/settings/my-style", { like: text }); flash("내 대본 샘플에 넣었어요. 다음 대본부터 이 말투를 참고해요."); } catch (e) { setError(e.message); }
  }
  async function copyCaption() {
    const c = script || job?.result || { caption: "", hashtags: [] };
    try { await navigator.clipboard.writeText(`${c.caption}\n\n${(c.hashtags || []).join(" ")}`); flash("캡션을 복사했어요"); } catch { setError("복사가 안 됐어요. 글을 직접 드래그해서 복사해 주세요."); }
  }
  async function openFolder() { try { await post("/api/open", { dir: job.result.dir }); flash("폴더를 열었어요"); } catch (e) { setError(e.message); } }

  return (
    <>
      <div className="topbar">
        <Link href="/reels" className="back">← 릴스 만들기</Link>
        {step > 1 && step < 4 && !busy && <button className="btn ghost small" onClick={() => setStep(step - 1)}>이전 단계</button>}
      </div>
      <h1>카드뉴스로 릴스 만들기</h1>
      <div className="steps">
        <span className={step === 1 ? "on" : "done"}>1. 카드뉴스</span>
        <span className={step === 2 ? "on" : step > 2 && script ? "done" : ""} style={!gemini && gemini !== null ? { opacity: 0.4 } : {}}>2. 훅 고르기</span>
        <span className={step === 3 ? "on" : step > 3 ? "done" : ""}>3. 목소리·음악</span>
        <span className={step === 4 ? "on" : ""}>4. 완성</span>
      </div>
      {error && <div className="notice warn">{error}</div>}
      {busy && <div className="notice info"><span className="spinner" />{busy}</div>}
      {toast && <div className="notice ok">{toast}</div>}

      {step === 1 && (
        <>
          <p className="sub">릴스로 만들 카드뉴스를 고르세요. 글은 그대로 두고 영상 대본으로 바꿔 드려요.</p>
          {sets.length === 0 && <div className="notice info">아직 만든 카드뉴스가 없어요. <Link href="/magazine" style={{ textDecoration: "underline" }}>매거진 콘텐츠 만들기</Link>에서 먼저 하나 만들어 주세요.</div>}
          <div className="setgrid">
            {sets.map((s) => (
              <div key={s.dir} className={`card selectable ${picked?.dir === s.dir ? "selected" : ""}`} style={{ padding: 12 }} onClick={() => !busy && choose(s)}>
                <div className="thumb" style={{ aspectRatio: "1080/1350" }}><img src={s.cover} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /></div>
                <div style={{ fontSize: 18, fontWeight: 800, marginTop: 8 }}>{s.title}</div>
                <div className="muted" style={{ fontSize: 15 }}>{s.date} · {s.slideCount}장</div>
              </div>
            ))}
          </div>
        </>
      )}

      {step === 2 && script && (
        <>
          <p className="sub">첫 3초에 나올 말을 고르세요. 하나 고르면 그게 첫 장면 자막이 돼요.</p>
          <div className="optgrid" style={{ gridTemplateColumns: "1fr" }}>
            {script.hooks.map((h, i) => (
              <div key={i} className={`opt ${hookIdx === i ? "on" : ""}`} onClick={() => setHookIdx(i)}>
                <div className="opt-body">{h.formula && <span className="badge">{h.formula}</span>}<div className="opt-title" style={{ fontSize: 24 }}>{h.text}</div></div>
              </div>
            ))}
          </div>
          <div className="card" style={{ background: "#FAFAF8" }}>
            <div className="muted" style={{ marginBottom: 8 }}>대본 미리보기 ({script.scenes.length}장면 · 약 {Math.round(script.scenes.reduce((a, s) => a + s.seconds, 0))}초)</div>
            {scenesWithHook().map((s, i) => <div key={i} style={{ padding: "6px 0", borderTop: i ? "1px solid var(--line)" : "none" }}><span className="muted">{i + 1}.</span> {s.caption}</div>)}
          </div>
          <button className="btn primary block" onClick={() => { setStep(3); window.scrollTo(0, 0); }}>이 훅으로 할게요</button>
        </>
      )}

      {step === 3 && (
        <>
          {script && (
            <div className="section">
              <h2>목소리</h2>
              <div className="section-sub">대본을 읽어줄 목소리예요. ▶ 를 누르면 들어볼 수 있어요.</div>
              <div className="optgrid">
                {voices.map((v) => (
                  <div key={v.id} className={`opt has-vp ${voiceId === v.id ? "on" : ""}`} onClick={() => setVoiceId(v.id)}>
                    <VoicePreview src={`/api/reels/voice-sample?voice=${v.id}`} onError={setError}>
                      <div className="opt-body"><div className="opt-title">{v.name} <span className="badge">{v.gender}</span></div><div className="opt-desc">{v.desc}</div></div>
                    </VoicePreview>
                  </div>
                ))}
                <div className={`opt ${voiceId === "none" ? "on" : ""}`} onClick={() => setVoiceId("none")}>
                  <div className="opt-body"><div className="opt-title">목소리 없이</div><div className="opt-desc">자막과 음악만</div></div>
                </div>
              </div>
            </div>
          )}
          <div className="section">
            <h2>배경음악</h2>
            <div className="section-sub">{script ? "영상 분위기에 맞는 음악을 고르세요." : "카드가 넘어가는 동안 깔릴 음악이에요."}</div>
            <div className="optgrid">
              {BGMS.map((b) => (
                <div key={b.id} className={`opt ${bgm === b.id ? "on" : ""}`} onClick={() => setBgm(b.id)}>
                  <div className="opt-body"><div className="opt-title">{b.name}</div>{b.desc && <div className="opt-desc">{b.desc}</div>}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="section"><button className="btn primary block" onClick={() => make()}>영상 만들기</button></div>
        </>
      )}

      {step === 4 && (
        <>
          {job && !job.done && (
            <div className="card" style={{ textAlign: "center", padding: 40 }}>
              <span className="spinner" style={{ width: 40, height: 40 }} />
              <div style={{ fontSize: 24, fontWeight: 800, marginTop: 14 }}>{job.stage}</div>
              <div className="muted">{job.progress || "조금만 기다려 주세요. 1~3분쯤 걸려요."}</div>
              <div className="muted" style={{ marginTop: 10, fontSize: 15 }}>대본 쓰기 ✓ → 그림 그리기 → 영상 만들기</div>
            </div>
          )}
          {job?.done && job.result && (
            <>
              <p className="sub">완성됐어요. {Math.round(job.result.seconds)}초 영상{job.result.hasVoice ? ", 목소리 포함" : ""}이에요. {job.result.mode === "slides" ? "카드가 한 장씩 넘어가는 영상이에요." : job.result.mode === "fallback" ? "(일부 그림을 못 만들어 카드뉴스 원본을 썼어요.)" : "장면마다 'AI로 다시'를 누르면 그 대사에 맞는 그림 하나만 새로 그려요. 내 사진으로 바꿀 수도 있어요."}</p>
              <div className="phone" style={{ maxWidth: 320 }}>
                <div className="screen" style={{ aspectRatio: "9/16" }}>
                  <video src={job.result.videoUrl} controls playsInline style={{ width: "100%", height: "100%", background: "#000" }} />
                </div>
              </div>
              {job.result.note && <div className="notice info">{job.result.note}</div>}
              {job.result.failed?.length > 0 && <div className="notice warn">{job.result.failed.map((f) => `${f.index + 1}번`).join(", ")} 장면은 그림을 못 만들어 카드뉴스 그림을 넣었어요. 아래에서 다시 만들 수 있어요.</div>}
              {job.result.mode !== "slides" && (
              <div className="card">
                <h2>장면</h2>
                <div className="scenes">
                  {job.result.images.map((img, i) => (
                    <div key={i} className="scene">
                      <div className="thumb" style={{ aspectRatio: "9/16" }}>{img && <img src={`/api/output?p=${encodeURIComponent(img)}&v=${Date.now()}`} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />}</div>
                      <div style={{ fontSize: 15, marginTop: 6 }}>{i + 1}. {sceneAt(i)?.caption}</div>
                      {sceneAt(i)?.say && sceneAt(i).say !== sceneAt(i).caption && (
                        <div style={{ fontSize: 13, color: "#777", marginTop: 2, lineHeight: 1.5 }}>
                          대사: {sceneAt(i).say}
                        </div>
                      )}
                      <div style={{ display: "grid", gap: 6, marginTop: 6 }}>
                        <button className="btn ghost small scene-btn" disabled={!!busy} onClick={() => redrawScene(i)}>🤖 AI로 다시</button>
                        <label className="btn ghost small scene-btn" style={{ cursor: "pointer" }}>📷 내 사진<input type="file" accept="image/png,image/jpeg,image/webp" style={{ display: "none" }} onChange={(e) => uploadSceneImage(i, e)} disabled={!!busy} /></label>
                      </div>
                    </div>
                  ))}
                </div>
                <button className="btn block" style={{ marginTop: 12 }} disabled={!!busy} onClick={() => make({ dir: job.result.dir, images: job.result.images, fits: job.result.fits })}>🎬 이 그림들로 영상 다시 만들기</button>
              </div>
              )}
              <div className="card">
                <h2>캡션</h2>
                <pre className="pre">{(script || job.result).caption}</pre>
                <div style={{ marginTop: 12, color: "var(--accent-ink)", fontWeight: 600 }}>{((script || job.result).hashtags || []).join(" ")}</div>
              </div>
              <div className="actions">
                <button className="btn primary primary-action" onClick={openFolder}>📂 영상 폴더 열기 (인스타에 올리기)</button>
                <div className="actions-grid">
                  <button className="btn" onClick={copyCaption}>캡션 복사</button>
                  {script && <button className="btn ghost" onClick={likeScript}>👍 대본 좋아요</button>}
                  <button className="btn ghost" onClick={() => { setStep(script ? 2 : 3); setJob(null); }}>{script ? "훅부터 다시" : "음악부터 다시"}</button>
                </div>
                <div className="actions-note">저장 위치: {job.result.absDir}</div>
              </div>
            </>
          )}
        </>
      )}
    </>
  );
}

export default function Page() {
  return <Suspense fallback={<div className="muted">불러오는 중…</div>}><CardnewsToReel /></Suspense>;
}
