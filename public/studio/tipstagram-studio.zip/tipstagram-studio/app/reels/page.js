import Link from "next/link";

export default function ReelsHome() {
  return (
    <>
      <div className="topbar"><Link href="/" className="back">← 처음으로</Link></div>
      <h1>릴스 만들기</h1>
      <p className="sub">어떻게 만들지 고르세요.</p>
      <Link href="/reels/cardnews" className="bigbtn">
        <div className="icon">🖼️</div>
        <div>
          <div className="label">카드뉴스로 만들기</div>
          <div className="desc">만들어둔 카드뉴스를 골라 내용에 맞는 그림 + 자막 + 목소리가 있는 영상으로 (훅 → 목소리·음악 → 완성)</div>
        </div>
      </Link>
      <Link href="/reels/reference" className="bigbtn">
        <div className="icon">🎯</div>
        <div>
          <div className="label">레퍼런스 따라찍기</div>
          <div className="desc">잘된 릴스를 넣으면 잘된 이유 → 내 대본 → 촬영 가이드 → 프롬프터</div>
        </div>
      </Link>

      <div className="muted" style={{ marginTop: 10 }}>그림체는 <Link href="/brand" style={{ textDecoration: "underline" }}>브랜드 설정</Link>에서, Gemini 연결은 <Link href="/settings" style={{ textDecoration: "underline" }}>설정</Link>에서 미리 해두면 좋아요.</div>
    </>
  );
}
