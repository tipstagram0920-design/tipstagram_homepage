"use client";
import { useEffect, useState } from "react";

const ENTERS = [
  { id: "rise-fade", name: "아래서 올라오며 나타남" },
  { id: "word-pop", name: "단어가 하나씩 튀어나옴" },
  { id: "typing", name: "글자가 하나씩 쳐짐" },
  { id: "slide-left", name: "왼쪽에서 밀려 들어옴" },
  { id: "fade", name: "그냥 나타남" },
];
const BOXES = [{ id: "dark", name: "검정 반투명 박스" }, { id: "brand", name: "내 브랜드색 박스" }, { id: "none", name: "박스 없이 (외곽선)" }];

async function post(url, body, method = "POST") {
  const r = await fetch(url, { method, headers: { "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || "문제가 생겼어요.");
  return j;
}

function ListEditor({ title, hint, items, onChange, placeholder, multiline = false, max = 10 }) {
  const [draft, setDraft] = useState("");
  return (
    <div className="field">
      <span style={{ display: "block", fontSize: 19, fontWeight: 700 }}>{title} <small style={{ fontWeight: 400, color: "var(--ink-soft)", fontSize: 16 }}>{hint}</small></span>
      {items.map((it, i) => (
        <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", margin: "8px 0" }}>
          <div style={{ flex: 1, background: "#FAFAF8", border: "2px solid var(--line)", borderRadius: 12, padding: "10px 14px", whiteSpace: "pre-wrap", fontSize: 17 }}>{it}</div>
          <button className="btn ghost small" onClick={() => onChange(items.filter((_, k) => k !== i))}>빼기</button>
        </div>
      ))}
      {items.length < max && (
        <div className="row" style={{ marginTop: 6 }}>
          {multiline ? <textarea value={draft} onChange={(e) => setDraft(e.target.value)} placeholder={placeholder} style={{ flex: 3, minHeight: 80 }} /> : <input type="text" value={draft} onChange={(e) => setDraft(e.target.value)} placeholder={placeholder} style={{ flex: 3 }} />}
          <button className="btn small" style={{ flex: 1 }} disabled={!draft.trim()} onClick={() => { onChange([...items, draft.trim()]); setDraft(""); }}>추가</button>
        </div>
      )}
    </div>
  );
}

export default function StyleSettings({ brandColor = "#D97757" }) {
  const [style, setStyle] = useState(null);
  const [defaultHooks, setDefaultHooks] = useState([]);
  const [msg, setMsg] = useState("");
  const [presetId, setPresetId] = useState(1);
  const [preset, setPreset] = useState(null);
  const [customized, setCustomized] = useState(false);

  useEffect(() => { post("/api/settings/my-style", null, "GET").then((j) => { setStyle(j.style); setDefaultHooks(j.defaultHooks || []); }).catch(() => {}); }, []);
  useEffect(() => { fetch(`/api/settings/presets/${presetId}`).then((r) => r.json()).then((j) => { setPreset(j.preset); setCustomized(j.customized); }); }, [presetId]);

  function flash(t) { setMsg(t); setTimeout(() => setMsg(""), 2000); }
  async function save(next) { setStyle(next); try { await post("/api/settings/my-style", { style: next }); flash("저장했어요"); } catch (e) { flash(e.message); } }
  async function reset(key) { try { const j = await post("/api/settings/my-style", { reset: key }); setStyle(j.style); flash("기본값으로 되돌렸어요"); } catch (e) { flash(e.message); } }
  function toggleFav(name) { const f = style.favoriteHooks.includes(name) ? style.favoriteHooks.filter((x) => x !== name) : [...style.favoriteHooks, name]; save({ ...style, favoriteHooks: f }); }

  async function savePreset(patch) {
    const next = { ...preset, caption: { ...preset.caption, ...(patch.caption || {}) }, enter: { ...preset.enter, ...(patch.enter || {}) } };
    setPreset(next);
    try { const j = await post(`/api/settings/presets/${presetId}`, patch, "PUT"); setPreset(j.preset); setCustomized(true); } catch (e) { flash(e.message); }
  }
  async function resetPreset() { try { const j = await post(`/api/settings/presets/${presetId}`, null, "DELETE"); setPreset(j.preset); setCustomized(false); flash("기본값으로 되돌렸어요"); } catch (e) { flash(e.message); } }

  if (!style) return null;
  const cap = preset?.caption || {};
  const scale = 0.22; // 1080 → 미리보기 폭
  const previewText = "계단 내려올 때 무릎 시리세요?";
  const boxStyle = cap.box === "brand" ? { background: brandColor } : cap.box === "none" ? { background: "transparent", WebkitTextStroke: `${(cap.outline || 4) * scale}px #000`, textShadow: "0 0 2px #000" } : { background: `rgba(0,0,0,${cap.boxOpacity ?? 0.6})` };

  return (
    <>
      {msg && <div className="notice ok">{msg}</div>}
      <div className="card">
        <h2>내 대본 샘플</h2>
        <p className="muted" style={{ marginTop: 4 }}>잘된 대본을 붙여 넣어 두면 말투·문장 길이·자주 쓰는 표현을 이 샘플에 맞춰 써요. 결과 화면의 "이 대본 좋아요"를 누르면 여기에 자동으로 쌓여요 (10개까지).</p>
        <ListEditor title="" hint="" items={style.scriptSamples} onChange={(v) => save({ ...style, scriptSamples: v })} placeholder="잘된 대본 한 편을 통째로 붙여 넣기" multiline max={10} />
        <button className="btn ghost small" onClick={() => reset("scriptSamples")}>샘플 비우기</button>
      </div>

      <div className="card">
        <h2>내 훅 공식</h2>
        <p className="muted" style={{ marginTop: 4 }}>⭐를 켜둔 공식을 먼저 써요. 내 공식을 추가하면 그걸 가장 먼저 써요.</p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, margin: "10px 0 16px" }}>
          {defaultHooks.map((h) => (
            <button key={h} className={`srcbtn`} style={{ padding: "8px 12px", borderColor: style.favoriteHooks.includes(h) ? "var(--accent)" : "var(--line)" }} onClick={() => toggleFav(h)}>
              <span style={{ fontSize: 17, fontWeight: 700 }}>{style.favoriteHooks.includes(h) ? "⭐ " : "☆ "}{h}</span>
            </button>
          ))}
        </div>
        <ListEditor title="내가 추가한 공식" hint="예: [대상]이 몰라서 손해 보는 [숫자]가지" items={style.hookFormulas} onChange={(v) => save({ ...style, hookFormulas: v })} placeholder="새 훅 공식" max={30} />
        <button className="btn ghost small" onClick={() => { reset("hookFormulas"); reset("favoriteHooks"); }}>기본값으로 되돌리기</button>
      </div>

      <div className="card">
        <h2>자주 쓰는 행동 유도 문구</h2>
        <ListEditor title="" hint="대본 마지막 장면에 이 문구들을 우선 써요" items={style.ctas} onChange={(v) => save({ ...style, ctas: v })} placeholder="예: 필요할 때 꺼내 보시게 저장해두세요" max={10} />
      </div>

      <div className="card">
        <h2>금지어</h2>
        <ListEditor title="" hint="대본·캡션에 절대 안 쓸 말" items={style.bannedWords} onChange={(v) => save({ ...style, bannedWords: v })} placeholder="예: 미쳤다, 대박" max={50} />
      </div>

      <div className="card">
        <h2>영상 자막 모양</h2>
        <p className="muted" style={{ marginTop: 4 }}>프리셋을 고르고 손잡이를 움직이면 오른쪽에 바로 보여요. 숫자는 안 적어도 돼요.</p>
        <div className="row" style={{ marginBottom: 14 }}>
          {[1, 2, 3, 4].map((id) => <button key={id} className={`btn ghost small ${presetId === id ? "" : ""}`} style={{ borderColor: presetId === id ? "var(--accent)" : "var(--line)" }} onClick={() => setPresetId(id)}>{id}번{preset && presetId === id ? ` ${preset.name}` : ""}</button>)}
        </div>
        {preset && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 240px", gap: 18, alignItems: "start" }}>
            <div>
              <label className="field"><span>글자 크기 <small>{cap.size}px</small></span><input type="range" min="40" max="100" step="2" value={cap.size || 64} onChange={(e) => setPreset({ ...preset, caption: { ...cap, size: Number(e.target.value) } })} onMouseUp={(e) => savePreset({ caption: { size: Number(e.target.value) } })} onTouchEnd={(e) => savePreset({ caption: { size: Number(e.target.value) } })} style={{ width: "100%" }} /></label>
              <label className="field"><span>자막 위치 <small>위↔아래 {cap.yPercent}%</small></span><input type="range" min="45" max="80" step="1" value={cap.yPercent || 62} onChange={(e) => setPreset({ ...preset, caption: { ...cap, yPercent: Number(e.target.value) } })} onMouseUp={(e) => savePreset({ caption: { yPercent: Number(e.target.value) } })} onTouchEnd={(e) => savePreset({ caption: { yPercent: Number(e.target.value) } })} style={{ width: "100%" }} /></label>
              <label className="field"><span>글자 색</span><div style={{ display: "flex", gap: 12, alignItems: "center" }}><input type="color" value={cap.color || "#FFFFFF"} onChange={(e) => savePreset({ caption: { color: e.target.value } })} /><span className="muted">{(cap.color || "#FFFFFF").toUpperCase()}</span></div></label>
              <label className="field"><span>박스</span>
                <div className="row">{BOXES.map((b) => <button key={b.id} className="btn ghost small" style={{ borderColor: (cap.box || "none") === b.id ? "var(--accent)" : "var(--line)" }} onClick={() => savePreset({ caption: { box: b.id } })}>{b.name}</button>)}</div></label>
              <label className="field"><span>등장 효과</span>
                <div className="row">{ENTERS.map((en) => <button key={en.id} className="btn ghost small" style={{ borderColor: preset.enter?.type === en.id ? "var(--accent)" : "var(--line)" }} onClick={() => savePreset({ enter: { type: en.id } })}>{en.name}</button>)}</div></label>
              <button className="btn ghost small" onClick={resetPreset} disabled={!customized}>{customized ? "이 프리셋 기본값으로 되돌리기" : "기본값 그대로예요"}</button>
            </div>
            <div style={{ width: 240, height: Math.round(240 * 16 / 9), background: "linear-gradient(160deg,#3a3f47,#1a1d22)", borderRadius: 14, position: "relative", overflow: "hidden", flex: "none" }}>
              <div style={{ position: "absolute", left: 0, right: 0, top: `${Math.round((250 / 1920) * 100)}%`, borderTop: "1px dashed rgba(255,255,255,.25)" }} />
              <div style={{ position: "absolute", left: 0, right: 0, bottom: `${Math.round((350 / 1920) * 100)}%`, borderTop: "1px dashed rgba(255,255,255,.25)" }} />
              <div style={{ position: "absolute", left: "50%", transform: "translate(-50%, -100%)", top: `${cap.yPercent || 62}%`, padding: `${6 * scale * 3}px ${12 * scale * 3}px`, borderRadius: 16 * scale, color: cap.color || "#fff", fontSize: (cap.size || 64) * scale, fontWeight: 800, textAlign: "center", lineHeight: 1.28, whiteSpace: "nowrap", ...boxStyle }}>
                {previewText.split(" ").slice(0, 3).join(" ")}<br />{previewText.split(" ").slice(3).join(" ")}
              </div>
              <div style={{ position: "absolute", bottom: 4, left: 0, right: 0, textAlign: "center", color: "rgba(255,255,255,.5)", fontSize: 11 }}>점선 밖은 인스타 글자에 가려요</div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
