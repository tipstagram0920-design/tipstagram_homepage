"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import StyleSettings from "./StyleSettings";

export default function SettingsPage() {
  const [state, setState] = useState({ connected: false, masked: "" });
  const [key, setKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);
  const [showGuide, setShowGuide] = useState(false);
  const [brandColor, setBrandColor] = useState("#D97757");

  useEffect(() => {
    fetch("/api/settings/gemini").then((r) => r.json()).then(setState).catch(() => {});
    fetch("/api/brand").then((r) => r.json()).then((b) => b?.color && setBrandColor(b.color)).catch(() => {});
  }, []);

  async function check() {
    setBusy(true); setMsg(null);
    try {
      const r = await fetch("/api/settings/gemini", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ key }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.message);
      setState(j); setKey("");
      setMsg({ ok: true, text: j.image?.ok ? "연결됐어요. 글 분석과 그림 생성 모두 쓸 수 있어요." : "연결됐어요. 글 분석은 되지만 그림 생성은 아직 안 돼요 (아래 안내)." });
    } catch (e) { setMsg({ ok: false, text: e.message }); } finally { setBusy(false); }
  }
  async function disconnect() {
    await fetch("/api/settings/gemini", { method: "DELETE" });
    setState({ connected: false, masked: "" }); setMsg(null);
  }

  return (
    <>
      <div className="topbar"><Link href="/" className="back">← 처음으로</Link></div>
      <h1>설정</h1>
      <p className="sub">릴스 만들기에 필요한 연결이에요. 한 번만 하면 돼요.</p>

      <div className="card">
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <h2 style={{ margin: 0 }}>Gemini 연결</h2>
          {state.connected && <span className="badge" style={{ background: "#E8F5EC", color: "#1D5B36", marginBottom: 0 }}>✓ 연결됨 {state.masked}</span>}
        </div>
        <p className="muted" style={{ marginTop: 6 }}>
          장면 그림을 그리고, 레퍼런스 영상을 읽는 데 구글 Gemini 를 써요. 구글 계정으로 무료 키를 받을 수 있어요.
        </p>

        <button className="btn ghost small" onClick={() => setShowGuide(!showGuide)}>{showGuide ? "키 받는 방법 접기" : "키 받는 방법 보기"}</button>
        {showGuide && (
          <ol style={{ paddingLeft: 22, lineHeight: 1.8, marginTop: 14 }}>
            <li><a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer" style={{ textDecoration: "underline", color: "var(--accent-ink)" }}>aistudio.google.com/apikey</a> 를 새 창에서 열어요. (구글 로그인)
              <div className="guide-img">그림 자리: AI Studio 첫 화면</div></li>
            <li>파란 <strong>Create API key</strong>(API 키 만들기) 버튼을 눌러요.
              <div className="guide-img">그림 자리: Create API key 버튼</div></li>
            <li>프로젝트를 물어보면 <strong>새 프로젝트 만들기</strong>를 고르고 그대로 진행해요.</li>
            <li><strong>AIza</strong> 또는 <strong>AQ</strong> 로 시작하는 긴 글자가 나오면 <strong>복사</strong>를 눌러요.
              <div className="guide-img">그림 자리: 키 복사 버튼</div></li>
            <li>아래 칸에 붙여 넣고 <strong>키 확인</strong>을 누르면 끝이에요.</li>
          </ol>
        )}

        <label className="field" style={{ marginTop: 18 }}>
          <span>{state.connected ? "다른 키로 바꾸려면 여기에 붙여 넣으세요" : "키 붙여넣기"}</span>
          <input type="text" value={key} onChange={(e) => setKey(e.target.value.trim())} placeholder="AIza… 또는 AQ.… 로 시작하는 글자" autoComplete="off" spellCheck={false} />
        </label>
        <div className="row">
          <button className="btn primary" onClick={check} disabled={busy || !key}>{busy ? (<><span className="spinner" />확인하는 중…</>) : "키 확인"}</button>
          {state.connected && <button className="btn ghost" onClick={disconnect}>연결 끊기</button>}
        </div>
        {msg && <div className={`notice ${msg.ok ? "ok" : "warn"}`}>{msg.ok ? "✅ " : ""}{msg.text}</div>}
        {state.connected && state.image && (
          <div className={`notice ${state.image.ok ? "ok" : "info"}`} style={{ marginTop: 8 }}>
            <div><strong>글 분석(영상 읽기·검수):</strong> ✓ 됩니다</div>
            <div><strong>그림 생성:</strong> {state.image.ok ? "✓ 됩니다" : state.image.reason === "billing" ? "✗ 아직 안 돼요 — 무료 등급은 그림 생성이 막혀 있어요" : `✗ ${state.image.message || "확인 실패"}`}</div>
            {!state.image.ok && state.image.reason === "billing" && (
              <div style={{ marginTop: 8, fontSize: 17 }}>
                켜는 방법: <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer" style={{ textDecoration: "underline" }}>aistudio.google.com/apikey</a> → 내 키 옆 프로젝트 → <strong>결제 설정(Set up billing)</strong> → 카드 등록. 그림 한 장에 약 50원이고, 릴스 하나(8장)에 400원쯤이에요. 켠 뒤 여기서 <strong>키 확인</strong>을 다시 누르면 반영돼요.
                <br />그림 생성 없이도 카드뉴스를 그대로 넘기는 릴스는 만들 수 있어요.
              </div>
            )}
          </div>
        )}
        <p className="muted" style={{ fontSize: 15, marginTop: 12 }}>키는 이 컴퓨터의 data/keys.json 에만 저장되고 어디로도 보내지 않아요(구글에 요청할 때만 써요).</p>
      </div>

      <h2 style={{ marginTop: 30 }}>내 스타일 맞추기</h2>
      <p className="sub">한 번 적어두면 모든 대본과 영상에 반영돼요. 기본값 파일은 그대로 두고 내 설정만 따로 저장돼요.</p>
      <StyleSettings brandColor={brandColor} />

      <div className="card">
        <h2>목소리 (TTS)</h2>
        <p className="muted" style={{ marginTop: 6 }}>대본을 읽어주는 목소리는 준비 중이에요. 지금은 자막과 음악으로 만들어져요.</p>
        <span className="badge">준비 중</span>
      </div>
    </>
  );
}
