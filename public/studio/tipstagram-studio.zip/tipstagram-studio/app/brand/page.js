"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function BrandPage() {
  const [brand, setBrand] = useState({ name: "", color: "#D97757", topic: "", toneSamples: ["", "", ""], logoFile: null, artStyle: "photo", styleRefFile: null });
  const [styles, setStyles] = useState([]);
  const [styleRefFile, setStyleRefFile] = useState(null);
  const [styleRefPreview, setStyleRefPreview] = useState(null);
  const [logoPreview, setLogoPreview] = useState(null);
  const [logoFile, setLogoFile] = useState(null);
  const [msg, setMsg] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/brand").then((r) => r.json()).then((b) => {
      setBrand(b);
      if (b.logoFile) setLogoPreview(`/api/brand/logo?v=${Date.now()}`);
      if (b.styleRefFile) setStyleRefPreview(`/api/brand/style-ref?v=${Date.now()}`);
    });
    fetch("/api/brand/styles").then((r) => r.json()).then((j) => setStyles(j.styles || [])).catch(() => {});
  }, []);

  function set(k, v) { setBrand((b) => ({ ...b, [k]: v })); }
  function setTone(i, v) { setBrand((b) => { const t = [...(b.toneSamples || ["", "", ""])]; t[i] = v; return { ...b, toneSamples: t }; }); }

  function onLogo(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    setLogoFile(f);
    setLogoPreview(URL.createObjectURL(f));
  }

  async function save() {
    setSaving(true); setMsg(null);
    try {
      const fd = new FormData();
      fd.append("name", brand.name || "");
      fd.append("color", brand.color || "#D97757");
      fd.append("topic", brand.topic || "");
      fd.append("toneSamples", JSON.stringify(brand.toneSamples || []));
      if (logoFile) fd.append("logo", logoFile);
      fd.append("artStyle", brand.artStyle || "photo");
      if (styleRefFile) fd.append("styleRef", styleRefFile);
      if (brand.styleRefFile === null && !styleRefFile) fd.append("clearStyleRef", "1");
      const r = await fetch("/api/brand", { method: "POST", body: fd });
      const j = await r.json();
      if (!r.ok) throw new Error(j.message || "저장 실패");
      setBrand(j);
      setLogoFile(null); setStyleRefFile(null);
      if (j.logoFile) setLogoPreview(`/api/brand/logo?v=${Date.now()}`);
      if (j.styleRefFile) setStyleRefPreview(`/api/brand/style-ref?v=${Date.now()}`); else setStyleRefPreview(null);
      setMsg({ ok: true, text: "저장했어요. 이제 만드는 모든 콘텐츠에 이 설정이 들어가요." });
    } catch (e) {
      setMsg({ ok: false, text: e.message });
    } finally { setSaving(false); }
  }

  return (
    <>
      <div className="topbar"><Link href="/" className="back">← 처음으로</Link></div>
      <h1>브랜드 설정</h1>
      <p className="sub">한 번만 적어두면 돼요. 카드뉴스의 색·로고·말투가 모두 여기서 나와요.</p>

      <div className="card">
        <label className="field">
          <span>계정 이름 <small>카드 위아래에 찍혀요. 예: 건강한 50대 연구소</small></span>
          <input type="text" value={brand.name} onChange={(e) => set("name", e.target.value)} placeholder="예: 건강한 50대 연구소" />
        </label>

        <label className="field">
          <span>로고 <small>없으면 계정 이름 첫 글자로 만들어 드려요. PNG·JPG 아무거나 괜찮아요.</small></span>
          <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
            <div style={{ width: 84, height: 84, borderRadius: 22, background: "#eee", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center", flex: "none" }}>
              {logoPreview ? <img src={logoPreview} alt="로고" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <span style={{ fontSize: 30, fontWeight: 800, color: "#999" }}>{(brand.name || "?").slice(0, 1)}</span>}
            </div>
            <input type="file" accept="image/png,image/jpeg,image/webp" onChange={onLogo} />
          </div>
        </label>

        <label className="field">
          <span>메인 색 1개 <small>네모를 누르면 색을 고를 수 있어요.</small></span>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <input type="color" value={brand.color || "#D97757"} onChange={(e) => set("color", e.target.value)} />
            <div style={{ fontSize: 22, fontWeight: 700 }}>{(brand.color || "").toUpperCase()}</div>
          </div>
        </label>

        <label className="field">
          <span>분야 (계정 주제) <small>소재는 이 분야 전체에서 골고루 나와요. 예: 중년 건강, 동네 필라테스, 홈카페 레시피</small></span>
          <input type="text" value={brand.topic} onChange={(e) => set("topic", e.target.value)} placeholder="예: 중년 건강" />
        </label>

        <div className="field">
          <span style={{ display: "block", fontSize: 19, fontWeight: 700, marginBottom: 8 }}>말투 예시 캡션 2~3개 <small style={{ fontWeight: 400, color: "var(--ink-soft)", fontSize: 16 }}>평소 올리던 글을 그대로 붙여 넣으세요. 클로드가 이 말투를 따라 써요.</small></span>
          {[0, 1, 2].map((i) => (
            <textarea key={i} value={brand.toneSamples?.[i] || ""} onChange={(e) => setTone(i, e.target.value)} placeholder={`말투 예시 ${i + 1}${i === 2 ? " (선택)" : ""}`} style={{ marginBottom: 10 }} />
          ))}
        </div>

        <div className="field">
          <span style={{ display: "block", fontSize: 19, fontWeight: 700, marginBottom: 4 }}>그림체 <small style={{ fontWeight: 400, color: "var(--ink-soft)", fontSize: 16 }}>릴스의 장면 그림을 이 느낌으로 그려요. 하나만 고르세요.</small></span>
          <div className="artstyles">
            {styles.map((st) => (
              <div key={st.id} className={`artstyle ${brand.artStyle === st.id ? "on" : ""}`} onClick={() => { set("artStyle", st.id); }}>
                <div className="pic">{st.sample ? <img src={`${st.sample}?v=1`} alt={st.name} /> : <span>샘플 준비 중</span>}</div>
                <div className="nm">{st.name}</div>
                <div className="ds">{st.desc}</div>
              </div>
            ))}
          </div>
          <details style={{ marginTop: 14 }}>
            <summary style={{ cursor: "pointer", fontWeight: 700 }}>고급: 내 스타일 사진 올리기</summary>
            <div className="muted" style={{ margin: "8px 0" }}>내가 좋아하는 그림이나 사진 1장을 올리면, 위 그림체 대신 이 사진의 느낌을 기준으로 그려요.</div>
            <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
              <div style={{ width: 72, height: 128, borderRadius: 12, background: "#eee", overflow: "hidden", flex: "none" }}>
                {styleRefPreview && <img src={styleRefPreview} alt="내 스타일" style={{ width: "100%", height: "100%", objectFit: "cover" }} />}
              </div>
              <input type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; setStyleRefFile(f); setStyleRefPreview(URL.createObjectURL(f)); set("styleRefFile", "pending"); }} />
              {(styleRefPreview) && <button className="btn ghost small" onClick={() => { setStyleRefFile(null); setStyleRefPreview(null); set("styleRefFile", null); }}>기준 사진 지우기</button>}
            </div>
          </details>
        </div>

        <button className="btn primary block" onClick={save} disabled={saving}>{saving ? "저장하는 중…" : "저장하기"}</button>
        {msg && <div className={`notice ${msg.ok ? "ok" : "warn"}`}>{msg.text}</div>}
      </div>
    </>
  );
}
