"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import TopicPicker from "@/components/TopicPicker";

const STYLES = [
  { id: "info", name: "정보형", desc: "깔끔한 흰 바탕, 번호와 제목이 또렷해요" },
  { id: "emotion", name: "감성형", desc: "큰 글씨 한 줄이 꽉 차요. 공감 글에 좋아요" },
  { id: "list", name: "리스트형", desc: "큰 번호로 차례차례. 방법·순서 글에 좋아요" },
  { id: "photo", name: "사진형", desc: "사진 위에 흰 글씨. 뉴스·매거진 느낌" },
];

/** 1080×1350 HTML 을 작은 네모에 축소해서 보여준다 */
function Thumb({ style }) {
  const box = useRef(null);
  const [scale, setScale] = useState(0.2);
  const [html, setHtml] = useState("");
  useEffect(() => {
    fetch(`/api/magazine/preview?style=${style}&slide=0`).then((r) => r.text()).then(setHtml);
    const update = () => box.current && setScale(box.current.clientWidth / 1080);
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, [style]);
  return (
    <div className="thumb" ref={box}>
      {html && <iframe title={style} srcDoc={html} style={{ transform: `scale(${scale})` }} scrolling="no" />}
    </div>
  );
}

async function post(url, body) {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || "문제가 생겼어요. 다시 눌러 주세요.");
  return j;
}

export default function MagazinePage() {
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [topic, setTopic] = useState(null);
  const [style, setStyle] = useState("info");
  const [content, setContent] = useState(null);
  const [result, setResult] = useState(null); // {dir, absDir, images}
  const [cur, setCur] = useState(0);
  const [editing, setEditing] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [toast, setToast] = useState("");
  const [reference, setReference] = useState(null); // {file, params, updatedAt}
  const [refBusy, setRefBusy] = useState(false);

  useEffect(() => {
    fetch("/api/magazine/reference").then((r) => r.json()).then((j) => j && j.params && setReference(j)).catch(() => {});
  }, []);

  function flash(t) { setToast(t); setTimeout(() => setToast(""), 2500); }

  function pickTopic(t) { setTopic(t); setStep(2); window.scrollTo(0, 0); }

  async function make() {
    setError(""); setStep(3); setResult(null); setContent(null); setEditing(false); setDirty(false); setCur(0);
    try {
      setBusy("1/2 글을 쓰고 있어요… (30초쯤 걸려요)");
      const g = await post("/api/magazine/generate", { topic, style });
      setContent(g.content);
      setBusy("2/2 카드를 그리고 있어요…");
      const r = await post("/api/magazine/render", { content: g.content, style, topicTitle: topic.title, topic });
      if (r.slides) setContent((c) => ({ ...c, slides: r.slides }));
      setResult(r);
      if (r.photoNotes?.length) flash(`${r.photoNotes.join(", ")}번 카드는 맞는 사진을 못 찾아 어두운 배경으로 뒀어요. 카드를 눌러 사진을 올려 보세요.`);
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  async function redraw() {
    setError(""); setBusy("고친 글로 카드를 다시 그리고 있어요…");
    try {
      const r = await post("/api/magazine/render", { content, style, topicTitle: topic.title, topic, dir: result?.dir });
      if (r.slides) setContent((c) => ({ ...c, slides: r.slides }));
      setResult(r); setDirty(false); setEditing(false);
      flash("다시 그렸어요");
    } catch (e) { setError(e.message); } finally { setBusy(""); }
  }

  async function saveImages() {
    if (dirty) await redraw();
    try { await post("/api/open", { dir: result.dir }); flash("폴더를 열었어요"); } catch (e) { setError(e.message); }
  }

  async function copyCaption() {
    const text = `${content.caption}\n\n${(content.hashtags || []).join(" ")}`.trim();
    try { await navigator.clipboard.writeText(text); flash("캡션을 복사했어요. 인스타에 붙여 넣으세요."); }
    catch { setError("복사가 안 됐어요. 아래 글을 직접 드래그해서 복사해 주세요."); }
  }

  async function uploadReference(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    setError(""); setRefBusy(true);
    try {
      const fd = new FormData(); fd.append("image", f);
      const r = await fetch("/api/magazine/reference", { method: "POST", body: fd });
      const j = await r.json();
      if (!r.ok) throw new Error(j.message || "레퍼런스를 읽지 못했어요.");
      setReference(j); setStyle("custom");
      flash("레퍼런스를 읽었어요: " + (j.params?.mood || "적용됐어요"));
    } catch (err) { setError(err.message); } finally { setRefBusy(false); e.target.value = ""; }
  }

  async function uploadPhoto(e) {
    const f = e.target.files?.[0];
    if (!f || !result) return;
    setError(""); setBusy("사진을 올리고 다시 그리고 있어요…");
    try {
      const fd = new FormData(); fd.append("dir", result.dir); fd.append("index", String(cur)); fd.append("image", f);
      const r = await fetch("/api/magazine/photo", { method: "POST", body: fd });
      const j = await r.json();
      if (!r.ok) throw new Error(j.message || "사진을 올리지 못했어요.");
      const next = { ...content, slides: content.slides.map((sl, i) => (i === cur ? { ...sl, photoFile: j.photoFile } : sl)) };
      setContent(next);
      const rr = await post("/api/magazine/render", { content: next, style, topicTitle: topic.title, topic, dir: result.dir });
      if (rr.slides) setContent((c) => ({ ...c, slides: rr.slides }));
      setResult(rr); flash("사진을 바꿨어요");
    } catch (err) { setError(err.message); } finally { setBusy(""); e.target.value = ""; }
  }

  async function anotherPhoto() {
    if (!result) return;
    setError(""); setBusy("다른 사진을 찾고 있어요…");
    try {
      const next = { ...content, slides: content.slides.map((sl, i) => (i === cur ? { ...sl, photoFile: undefined, photoIndex: (sl.photoIndex || 0) + 1 } : sl)) };
      setContent(next);
      const rr = await post("/api/magazine/render", { content: next, style, topicTitle: topic.title, topic, dir: result.dir });
      if (rr.slides) setContent((c) => ({ ...c, slides: rr.slides }));
      setResult(rr); flash("사진을 바꿨어요");
    } catch (err) { setError(err.message); } finally { setBusy(""); }
  }

  function editSlide(k, v) {
    setContent((c) => { const slides = [...c.slides]; slides[cur] = { ...slides[cur], [k]: v }; return { ...c, slides }; });
    setDirty(true);
  }

  const slide = content?.slides?.[cur];
  const total = content?.slides?.length || 0;

  return (
    <>
      <div className="topbar">
        <Link href="/" className="back">← 처음으로</Link>
        {step > 1 && !busy && <button className="btn ghost small" onClick={() => { setStep(step - 1); setError(""); }}>이전 단계</button>}
      </div>
      <h1>매거진 카드뉴스 만들기</h1>
      <div className="steps">
        <span className={step === 1 ? "on" : "done"}>1. 소재 고르기</span>
        <span className={step === 2 ? "on" : step > 2 ? "done" : ""}>2. 스타일 고르기</span>
        <span className={step === 3 ? "on" : ""}>3. 완성</span>
      </div>

      {error && <div className="notice warn">{error}</div>}
      {busy && <div className="notice info"><span className="spinner" />{busy}</div>}
      {toast && <div className="notice ok">{toast}</div>}

      {/* ---------- 1단계 ---------- */}
      {step === 1 && <TopicPicker onPick={pickTopic} />}

      {/* ---------- 2단계 ---------- */}
      {step === 2 && (
        <>
          <p className="sub">고른 소재: <strong>{topic?.title}</strong><br />카드 모양을 고르세요. 색과 로고는 브랜드 설정대로 들어가요.</p>
          <div className="styles">
            {STYLES.map((s) => (
              <div key={s.id} className={`card selectable ${style === s.id ? "selected" : ""}`} style={{ padding: 14 }} onClick={() => setStyle(s.id)}>
                <Thumb style={s.id} />
                <div style={{ fontSize: 22, fontWeight: 800, marginTop: 12 }}>{s.name}</div>
                <div className="muted">{s.desc}</div>
              </div>
            ))}
          </div>
          <div className={`card selectable ${style === "custom" ? "selected" : ""}`} style={{ marginTop: 14, padding: 18 }} onClick={() => reference && setStyle("custom")}>
            <div style={{ display: "flex", gap: 18, alignItems: "center", flexWrap: "wrap" }}>
              <div style={{ width: 150, flex: "none" }}>
                {reference ? <Thumb style="custom" key={reference.updatedAt} /> : <div className="thumb" style={{ display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40 }}>📷</div>}
              </div>
              <div style={{ flex: 1, minWidth: 220 }}>
                <div style={{ fontSize: 22, fontWeight: 800 }}>내 레퍼런스로</div>
                <div className="muted" style={{ marginBottom: 10 }}>
                  {reference ? `읽은 느낌: ${reference.params?.mood || "적용됨"}` : "마음에 드는 카드뉴스 캡처 1장을 올리면 그 생김새(색·배치·분위기)로 만들어요."}
                </div>
                {refBusy ? (
                  <div className="notice info" style={{ margin: 0 }}><span className="spinner" />레퍼런스를 읽고 있어요… (30초쯤)</div>
                ) : (
                  <label className="btn ghost small" style={{ cursor: "pointer" }} onClick={(e) => e.stopPropagation()}>
                    {reference ? "다른 레퍼런스 올리기" : "캡처 올리기"}
                    <input type="file" accept="image/png,image/jpeg,image/webp" style={{ display: "none" }} onChange={uploadReference} />
                  </label>
                )}
              </div>
            </div>
          </div>
          <button className="btn primary block" style={{ marginTop: 22 }} onClick={make} disabled={refBusy}>이 스타일로 만들기</button>
        </>
      )}

      {/* ---------- 3단계 ---------- */}
      {step === 3 && result && content && (
        <>
          <p className="sub">완성됐어요. 카드를 누르면 글{style === "photo" ? "과 사진" : ""}을 고칠 수 있어요.</p>
          <div className="phone">
            <div className="screen">
              <img src={result.images[cur]?.url} alt={`카드 ${cur + 1}`} />
              <div className="tap" onClick={() => setEditing(true)} />
              {cur > 0 && <button className="nav l" onClick={() => setCur(cur - 1)}>‹</button>}
              {cur < total - 1 && <button className="nav r" onClick={() => setCur(cur + 1)}>›</button>}
            </div>
          </div>
          <div className="dots">{content.slides.map((_, i) => <i key={i} className={i === cur ? "on" : ""} onClick={() => setCur(i)} />)}</div>
          <div className="hint">{cur + 1} / {total} 장 · 카드를 누르면 글 고치기</div>

          {editing && slide && (
            <div className="card editbox">
              <h2>{cur + 1}번 카드 글 고치기</h2>
              <label className="field"><span>제목{slide.type === "cover" ? " (두 줄이면 줄바꿈)" : ""}</span>
                <textarea value={slide.title || ""} onChange={(e) => editSlide("title", e.target.value)} style={{ minHeight: 70 }} /></label>
              {slide.type === "cover" ? (
                <label className="field"><span>부제</span><input type="text" value={slide.sub || ""} onChange={(e) => editSlide("sub", e.target.value)} /></label>
              ) : (
                <label className="field"><span>본문</span><textarea value={slide.body || ""} onChange={(e) => editSlide("body", e.target.value)} /></label>
              )}
              {slide.type === "body" && (
                <label className="field"><span>핵심 한 줄 (비워도 돼요)</span><input type="text" value={slide.point || ""} onChange={(e) => editSlide("point", e.target.value)} /></label>
              )}
              {style === "photo" && (
                <>
                  <label className="field"><span>코너 이름 <small>카드 위 작은 파란 글씨. 예: NOW, HEALTH, TIP</small></span><input type="text" value={slide.tag || ""} onChange={(e) => editSlide("tag", e.target.value)} /></label>
                  <div className="field">
                    <span style={{ display: "block", fontSize: 19, fontWeight: 700, marginBottom: 8 }}>배경 사진</span>
                    <div className="row">
                      <label className="btn ghost small" style={{ cursor: "pointer", flex: 1 }}>
                        내 사진 올리기
                        <input type="file" accept="image/png,image/jpeg,image/webp" style={{ display: "none" }} onChange={uploadPhoto} />
                      </label>
                      <button className="btn ghost small" style={{ flex: 1 }} onClick={anotherPhoto} disabled={!!busy}>다른 사진 찾기</button>
                    </div>
                    {slide.photoCredit && <div className="muted" style={{ fontSize: 15, marginTop: 8 }}>지금 사진 출처: {slide.photoCredit} (카드 왼쪽 아래에 작게 표시돼요)</div>}
                  </div>
                </>
              )}
              <div className="row">
                <button className="btn primary" onClick={redraw} disabled={!dirty || !!busy}>고친 글로 다시 그리기</button>
                <button className="btn ghost" onClick={() => setEditing(false)}>닫기</button>
              </div>
            </div>
          )}

          <div className="actions">
            <button className="btn primary primary-action" onClick={saveImages} disabled={!!busy}>💾 이미지 저장하고 폴더 열기</button>
            <div className="actions-grid">
              <button className="btn" onClick={copyCaption}>캡션 복사</button>
              <Link href={`/reels/cardnews?dir=${encodeURIComponent(result.dir)}`} className="btn" style={{ background: "#1F4E9C" }}>🎬 릴스로 만들기</Link>
              <button className="btn ghost" onClick={make} disabled={!!busy}>🔄 다시 만들기</button>
            </div>
            {dirty && <div className="notice info" style={{ marginTop: 10 }}>글을 고쳤어요. "이미지 저장"을 누르면 고친 글로 다시 그려서 저장해요.</div>}
            <div className="actions-note">저장 위치: {result.absDir}</div>
          </div>

          <div className="card" style={{ marginTop: 20 }}>
            <h2>캡션</h2>
            <pre className="pre">{content.caption}</pre>
            <div style={{ marginTop: 14, color: "var(--accent-ink)", fontWeight: 600 }}>{(content.hashtags || []).join(" ")}</div>
          </div>
        </>
      )}
      {step === 3 && !result && !busy && !error && <div className="muted">준비 중…</div>}
    </>
  );
}
