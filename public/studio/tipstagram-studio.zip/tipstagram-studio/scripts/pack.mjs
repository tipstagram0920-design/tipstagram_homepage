#!/usr/bin/env node
// (운영자용) 배포 묶기: zip + 설치 파일을 홈페이지 public/studio/ 로 복사한다. node_modules·빌드·내 설정·결과물은 뺀다.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, "installer", "config.json"), "utf8"));
const version = fs.readFileSync(path.join(ROOT, "VERSION"), "utf8").trim();
const siteUrl = process.env.SITE_URL || cfg.siteUrl;
if (!siteUrl || siteUrl.includes("__")) { console.error("installer/config.json 의 siteUrl 을 먼저 채우세요 (예: https://tipstagram-homepage.vercel.app)"); process.exit(1); }
const outZip = path.join(os.homedir(), "Desktop", "tipstagram-studio.zip");
const excludes = ["node_modules/*", ".next/*", "data/*", "output/*", ".git/*", "runtime/*", "prompts/custom/*", "presets/custom/*", "installer/*", "*.log", ".DS_Store", "*/.DS_Store"];
fs.rmSync(outZip, { force: true });
const r = spawnSync("zip", ["-r", "-q", outZip, "tipstagram-studio", ...excludes.flatMap((e) => ["-x", `tipstagram-studio/${e}`])], { cwd: path.dirname(ROOT), stdio: "inherit" });
if (r.status !== 0) { console.error("zip 실패 (Mac/Linux 의 zip 명령이 필요해요)"); process.exit(1); }
console.log(`✅ zip v${version}: ${outZip} (${(fs.statSync(outZip).size / 1048576).toFixed(1)}MB)`);

// 홈페이지 public/studio/ 로 복사 (설치 파일은 자리표시자를 채워서)
const site = process.env.SITE_DIR || path.join(path.dirname(ROOT), "tipstagram homepage", "tipstagram", "public", "studio");
if (fs.existsSync(path.dirname(site))) {
  fs.mkdirSync(site, { recursive: true });
  fs.copyFileSync(outZip, path.join(site, "tipstagram-studio.zip"));
  for (const f of fs.readdirSync(path.join(ROOT, "installer"))) {
    if (f === "config.json") continue;
    const src = fs.readFileSync(path.join(ROOT, "installer", f), "utf8").replace(/__SITE_URL__/g, siteUrl).replace(/__NODE_VER__/g, cfg.nodeVersion);
    fs.writeFileSync(path.join(site, f), f.endsWith(".bat") ? src.replace(/\r?\n/g, "\r\n") : src, "utf8");
  }
  fs.writeFileSync(path.join(site, "VERSION"), version + "\n");
  console.log(`✅ 홈페이지 public/studio/ 갱신: ${fs.readdirSync(site).join(", ")}`);
  console.log("   → 홈페이지를 커밋·배포하면 수강생에게 반영돼요.");
} else {
  console.log("· 홈페이지 폴더가 없어 public/studio 복사는 건너뜀 (SITE_DIR 로 지정 가능)");
}
