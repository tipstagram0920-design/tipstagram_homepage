#!/usr/bin/env node
// 설치 스크립트 — "설치해줘" 한 마디로 끝나게 하는 한 파일.
// 순서: OS/노드 확인 → 클로드 확인 → 의존성 설치 → 브라우저(Chromium) 설치 → 빌드 → 바탕화면 아이콘 → 실행 확인
import { spawnSync, spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(ROOT);
const IS_WIN = process.platform === "win32";
const IS_MAC = process.platform === "darwin";
const PORT = 3777;
const args = new Set(process.argv.slice(2));

const log = (s) => console.log(s);
const step = (n, s) => console.log(`\n${"─".repeat(60)}\n[${n}/7] ${s}\n${"─".repeat(60)}`);
function fail(msg, hint) {
  console.error(`\n❌ 실패: ${msg}`);
  if (hint) console.error(`   → ${hint}`);
  process.exit(1);
}
function run(cmd, cmdArgs, opts = {}) {
  const r = spawnSync(cmd, cmdArgs, { stdio: "inherit", shell: IS_WIN, windowsHide: true, ...opts });
  if (r.error) throw r.error;
  return r.status;
}
function capture(cmd, cmdArgs) {
  const r = spawnSync(cmd, cmdArgs, { encoding: "utf8", shell: IS_WIN, windowsHide: true });
  return { ok: r.status === 0, out: ((r.stdout || "") + (r.stderr || "")).trim() };
}

// ── 1. OS · Node ────────────────────────────────────────────────
step(1, "컴퓨터와 Node.js 확인");
log(`운영체제: ${IS_WIN ? "Windows" : IS_MAC ? "Mac" : process.platform} (${os.release()}), 사용자 폴더: ${os.homedir()}`);
const [major, minor] = process.versions.node.split(".").map(Number);
if (major < 20 || (major === 20 && minor < 9)) fail(`Node.js 가 너무 오래됐어요 (지금 ${process.versions.node}).`, "https://nodejs.org 에서 LTS 버전을 설치한 뒤 다시 실행해 주세요.");
log(`Node.js ${process.versions.node} ✓  (경로: ${process.execPath})`);

// ── 2. Claude Code ──────────────────────────────────────────────
step(2, "Claude Code(claude 명령) 확인");
function findClaude() {
  const probe = capture(IS_WIN ? "where" : "which", ["claude"]);
  if (probe.ok && probe.out) return probe.out.split(/\r?\n/)[0].trim();
  const home = os.homedir();
  const candidates = IS_WIN
    ? [path.join(process.env.APPDATA || "", "npm", "claude.cmd"), path.join(home, ".local", "bin", "claude.exe"), path.join(process.env.LOCALAPPDATA || "", "Programs", "claude", "claude.exe")]
    : ["/opt/homebrew/bin/claude", "/usr/local/bin/claude", path.join(home, ".local/bin/claude"), path.join(home, ".claude/local/claude"), path.join(path.dirname(process.execPath), "claude")];
  if (!IS_WIN) {
    const nvm = path.join(home, ".nvm/versions/node");
    if (fs.existsSync(nvm)) for (const v of fs.readdirSync(nvm)) candidates.push(path.join(nvm, v, "bin/claude"));
  }
  return candidates.find((c) => c && fs.existsSync(c)) || null;
}
const claudePath = findClaude();
if (!claudePath) fail("claude 명령을 찾지 못했어요.", "Claude Code 가 설치돼 있어야 해요. 설치 후 터미널을 새로 열고 다시 실행해 주세요. (설치: https://claude.com/claude-code)");
const ver = capture(IS_WIN ? `"${claudePath}"` : claudePath, ["--version"]);
log(`claude 경로: ${claudePath}`);
log(`claude 버전: ${ver.out.split(/\r?\n/)[0] || "(확인 불가)"} ${ver.ok ? "✓" : "⚠"}`);

// ── 3. 의존성 설치 ─────────────────────────────────────────────
step(3, "필요한 프로그램 내려받기 (npm install — 1~3분)");
if (args.has("--skip-install") && fs.existsSync("node_modules/next")) log("건너뜀 (--skip-install)");
else {
  // npm 은 PATH 가 아니라 지금 node 옆의 것(휴대용 node 는 PATH 에 없다)
  const npmBeside = path.join(path.dirname(process.execPath), IS_WIN ? "npm.cmd" : "npm");
  const NPM = fs.existsSync(npmBeside) ? npmBeside : (IS_WIN ? "npm.cmd" : "npm");
  const code = run(IS_WIN ? `"${NPM}"` : NPM, ["install", "--no-audit", "--no-fund", "--loglevel=error"]);
  if (code !== 0) fail("npm install 이 실패했어요.", "인터넷 연결을 확인하고 다시 실행해 주세요. 회사 네트워크(프록시)면 집 와이파이에서 해 보세요.");
}
log("의존성 설치 ✓");

// ── 4. 카드 그리는 브라우저 ───────────────────────────────────
step(4, "카드를 그릴 브라우저(Chromium) 내려받기 (1~2분)");
{
  const code = run(process.execPath, ["node_modules/playwright/cli.js", "install", "chromium"]);
  if (code !== 0) fail("Chromium 다운로드가 실패했어요.", "인터넷 연결을 확인하고 `node scripts/install.mjs --skip-install` 로 다시 실행해 주세요.");
}
log("Chromium ✓");

// ── 5. 빌드 ────────────────────────────────────────────────────
step(5, "앱 빌드 (1~2분)");
if (args.has("--skip-build") && fs.existsSync(".next/BUILD_ID")) log("건너뜀 (--skip-build)");
else {
  const code = run(process.execPath, ["node_modules/next/dist/bin/next", "build"]);
  if (code !== 0) fail("빌드가 실패했어요.", "위 오류 내용을 그대로 Claude 에게 보여주면 고쳐 줘요.");
}
log("빌드 ✓");

// ── 6. 설정 저장 + 바탕화면 아이콘 ──────────────────────────────
step(6, "설정 저장 · 바탕화면 아이콘 만들기");
fs.mkdirSync("data", { recursive: true });
fs.mkdirSync("output", { recursive: true });
const prev = fs.existsSync("data/system.json") ? JSON.parse(fs.readFileSync("data/system.json", "utf8")) : {};
fs.writeFileSync("data/system.json", JSON.stringify({ ...prev, os: process.platform, nodePath: process.execPath, claudePath, model: prev.model || "sonnet", installedAt: new Date().toISOString() }, null, 2));
log("data/system.json ✓");

function desktopDir() {
  const home = os.homedir();
  const c = [];
  if (IS_WIN) {
    if (process.env.OneDrive) c.push(path.join(process.env.OneDrive, "Desktop"), path.join(process.env.OneDrive, "바탕 화면"));
    c.push(path.join(home, "Desktop"), path.join(home, "바탕 화면"));
  } else c.push(path.join(home, "Desktop"));
  return c.find((d) => fs.existsSync(d)) || null;
}
const desktop = desktopDir();
let launcher = null;
if (!desktop) log("⚠ 바탕화면 폴더를 찾지 못했어요. 프로젝트 폴더의 '시작' 파일로 실행하면 돼요.");
else if (IS_MAC) {
  launcher = path.join(desktop, "팁스타그램 스튜디오.command");
  fs.writeFileSync(launcher, `#!/bin/bash\ncd "${ROOT}"\n"${process.execPath}" scripts/start.mjs\n`, { mode: 0o755 });
  fs.chmodSync(launcher, 0o755);
  spawnSync("xattr", ["-d", "com.apple.quarantine", launcher], { stdio: "ignore" });
} else if (IS_WIN) {
  // 1순위: 바로가기(.lnk) — 한글 경로도 안전. 2순위: .bat
  const target = path.join(ROOT, "시작.bat");
  launcher = path.join(desktop, "팁스타그램 스튜디오.lnk");
  const ps = `$s=(New-Object -ComObject WScript.Shell).CreateShortcut('${launcher.replace(/'/g, "''")}');$s.TargetPath='${target.replace(/'/g, "''")}';$s.WorkingDirectory='${ROOT.replace(/'/g, "''")}';$s.IconLocation='%SystemRoot%\\System32\\shell32.dll,220';$s.Save()`;
  const r = spawnSync("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps], { stdio: "ignore", windowsHide: true });
  if (r.status !== 0 || !fs.existsSync(launcher)) {
    launcher = path.join(desktop, "팁스타그램 스튜디오.bat");
    fs.writeFileSync(launcher, `@echo off\r\nchcp 65001 >nul\r\ncd /d "${ROOT}"\r\n"${process.execPath}" scripts\\start.mjs\r\npause\r\n`);
  }
}
if (launcher) log(`바탕화면 아이콘 ✓  ${launcher}`);

// ── 7. 실행 확인 ───────────────────────────────────────────────
step(7, "실행 확인 (서버를 잠깐 켰다가 끕니다)");
async function health() {
  try { const r = await fetch(`http://localhost:${PORT}/api/health`); return r.ok; } catch { return false; }
}
if (await health()) log(`이미 ${PORT}번 포트에서 스튜디오가 켜져 있어요 ✓ (그대로 쓰면 돼요)`);
else {
  const child = spawn(process.execPath, ["node_modules/next/dist/bin/next", "start", "-p", String(PORT)], { stdio: "ignore", windowsHide: true });
  let ok = false;
  for (let i = 0; i < 60 && !ok; i++) { await new Promise((r) => setTimeout(r, 1000)); ok = await health(); }
  if (IS_WIN) spawnSync("taskkill", ["/pid", String(child.pid), "/T", "/F"], { stdio: "ignore", windowsHide: true });
  else child.kill();
  if (!ok) fail("서버가 켜지지 않았어요.", `node scripts/start.mjs 를 직접 실행해서 오류 내용을 Claude 에게 보여 주세요.`);
  log("서버 응답 ✓");
}

console.log(`
✅ 설치가 끝났어요!

  실행 방법: 바탕화면의 "팁스타그램 스튜디오" 를 더블클릭하세요.
  ${IS_MAC ? "(처음 한 번 '확인되지 않은 개발자' 창이 뜨면: 아이콘을 오른쪽 클릭 → 열기)" : "(검은 창이 뜨고 잠시 뒤 브라우저가 열려요. 검은 창은 닫지 마세요.)"}
  주소: http://localhost:${PORT}
`);
