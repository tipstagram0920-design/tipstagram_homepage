#!/usr/bin/env node
// 그림체 6종 샘플 이미지 생성 (운영자용, Gemini 키 필요). public/styles/{id}.png 로 저장 — 설치팩에 같이 들어간다.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(ROOT);
const { ART_STYLES, IMAGE_RULES } = await import("../lib/reels/styles.js");
const { generateImage, hasGemini, inspectImage } = await import("../lib/reels/gemini.js");
if (!hasGemini()) { console.error("Gemini 키가 없어요. 설정 화면에서 먼저 연결해 주세요."); process.exit(1); }
const SUBJECT = "A middle-aged Korean woman in her 50s walking slowly on a quiet park path in the morning, seen from behind at a slight angle, trees and soft light";
const outDir = path.join(ROOT, "public", "styles");
fs.mkdirSync(outDir, { recursive: true });
const only = process.argv[2];
for (const st of ART_STYLES) {
  if (only && st.id !== only) continue;
  const file = path.join(outDir, `${st.id}.png`);
  let ok = false;
  for (let attempt = 1; attempt <= 3 && !ok; attempt++) {
    try {
      const img = await generateImage(`${SUBJECT}. Style: ${st.prompt}. ${IMAGE_RULES}`, { aspect: "9:16" });
      const check = await inspectImage(img, null).catch(() => ({ hasText: false }));
      if (check.hasText) { console.log(`${st.id}: 글자 감지 → 다시 (${attempt})`); continue; }
      fs.writeFileSync(file, img.buffer);
      console.log(`${st.id}: ${path.relative(ROOT, file)} (${(img.buffer.length / 1024).toFixed(0)}KB)`);
      ok = true;
    } catch (e) {
      console.log(`${st.id}: 실패 (${attempt}) ${e.friendly || e.message} ${e.detail ? "| " + String(e.detail).slice(0, 200) : ""}`);
    }
  }
}
