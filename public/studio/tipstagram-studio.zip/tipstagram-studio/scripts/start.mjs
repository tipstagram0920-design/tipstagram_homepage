#!/usr/bin/env node
// 스튜디오 실행 — 서버를 켜고 브라우저를 연다. 창을 닫으면 꺼진다.
import { spawn, spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(ROOT);
const PORT = Number(process.env.STUDIO_PORT || 3777);
const URL_ = `http://localhost:${PORT}`;
const IS_WIN = process.platform === "win32";
const noOpen = process.argv.includes("--no-open");

function openBrowser() {
  if (noOpen) return;
  if (process.platform === "darwin") spawn("open", [URL_], { stdio: "ignore", detached: true }).unref();
  else if (IS_WIN) spawn("cmd", ["/c", "start", "", URL_], { stdio: "ignore", detached: true, windowsHide: true }).unref();
  else spawn("xdg-open", [URL_], { stdio: "ignore", detached: true }).unref();
}
async function health() {
  try { const r = await fetch(`${URL_}/api/health`); return r.ok; } catch { return false; }
}

if (!fs.existsSync(path.join(ROOT, ".next", "BUILD_ID"))) {
  console.error("아직 설치가 안 됐어요. Claude Code 에서 이 폴더를 열고 \"설치해줘\" 라고 말해 주세요. (또는: node scripts/install.mjs)");
  process.exit(1);
}

if (await health()) {
  console.log(`스튜디오가 이미 켜져 있어요 → ${URL_}`);
  console.log("(새로 고친 코드를 반영하려면 켜져 있는 창을 닫고 다시 실행하세요)");
  openBrowser();
  process.exit(0);
}

console.log("팁스타그램 수익화 스튜디오를 켜는 중이에요…");
const child = spawn(process.execPath, ["node_modules/next/dist/bin/next", "start", "-p", String(PORT)], { stdio: ["ignore", "inherit", "inherit"], windowsHide: true });
let ok = false;
for (let i = 0; i < 60 && !ok; i++) { await new Promise((r) => setTimeout(r, 1000)); ok = await health(); }
if (!ok) {
  console.error(`\n❌ 서버가 켜지지 않았어요. ${PORT}번 포트를 다른 프로그램이 쓰고 있을 수 있어요. 컴퓨터를 다시 시작하고 해 보세요.`);
  child.kill();
  process.exit(1);
}
console.log(`\n✅ 켜졌어요 → ${URL_}\n이 창을 닫으면 스튜디오가 꺼져요. 다 쓰고 나면 닫아도 괜찮아요.\n`);
openBrowser();

const stop = () => {
  if (IS_WIN) spawnSync("taskkill", ["/pid", String(child.pid), "/T", "/F"], { stdio: "ignore", windowsHide: true });
  else child.kill();
  process.exit(0);
};
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
child.on("exit", (code) => process.exit(code ?? 0));
