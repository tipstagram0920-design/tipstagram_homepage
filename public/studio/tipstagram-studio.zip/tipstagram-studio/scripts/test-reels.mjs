#!/usr/bin/env node
// 1단계 테스트: 임의 대본 + 임의 이미지 3장으로 프리셋 4종 영상을 하나씩 만든다.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(ROOT);
const { makeReel } = await import("../lib/reels/index.js");
const { probeSeconds } = await import("../lib/reels/compose.js");
const { chromium } = await import("playwright");

const brand = { name: "건강한 50대 연구소", color: "#2E7D5B" };
const scenes = [
  { scene: 1, seconds: 3, caption: "계단 내려올 때 무릎 시리세요?", emphasis: "무릎", visual: "EN: senior walking down stairs / KO: 계단" },
  { scene: 2, seconds: 3, caption: "발 디디는 순서가 문제예요", emphasis: "순서", visual: "" },
  { scene: 3, seconds: 3, caption: "뒤꿈치부터 천천히", emphasis: "뒤꿈치", visual: "" },
  { scene: 4, seconds: 3, caption: "난간 잡고 체중 나누기", emphasis: "체중", visual: "" },
  { scene: 5, seconds: 3, caption: "무릎은 살짝 구부린 채로", emphasis: "살짝", visual: "" },
  { scene: 6, seconds: 3, caption: "오늘 계단에서 한 번만 해보세요", emphasis: "한 번만", visual: "" },
];

// 임의 이미지 3장 (글자 없는 그라데이션 + 도형)
const imgDir = path.join(ROOT, "output", "_test", "images");
fs.mkdirSync(imgDir, { recursive: true });
const b = await chromium.launch();
const page = await b.newPage({ viewport: { width: 1080, height: 1920 } });
const palettes = [["#1b3a4b", "#f4a261"], ["#5b3a29", "#e9c46a"], ["#264653", "#2a9d8f"]];
const images = [];
for (let i = 0; i < 3; i++) {
  const [a, c] = palettes[i];
  await page.setContent(`<html><body style="margin:0;width:1080px;height:1920px;background:linear-gradient(160deg,${a},${c});position:relative;overflow:hidden">
    <div style="position:absolute;left:${200 + i * 120}px;top:${400 + i * 90}px;width:520px;height:520px;border-radius:50%;background:rgba(255,255,255,.25)"></div>
    <div style="position:absolute;left:120px;top:1100px;width:840px;height:300px;border-radius:40px;background:rgba(0,0,0,.18)"></div></body></html>`);
  const f = path.join(imgDir, `img${i + 1}.png`);
  await page.screenshot({ path: f });
  images.push(f);
}
await b.close();

const results = [];
for (const presetId of [1, 2, 3, 4]) {
  const t0 = Date.now();
  const r = await makeReel({
    scenes, images: scenes.map((_, i) => images[i % 3]), presetId, brand,
    caption: "테스트 캡션", hashtags: ["#테스트"],
    endCard: presetId === 4 ? ["10월 20일 ~ 24일", "공구가 20% 할인", "댓글에 '무릎' 남겨주세요"] : undefined,
    dir: path.join(ROOT, "output", "_test", `preset${presetId}`), label: "테스트",
    onProgress: () => {},
  });
  const sec = await probeSeconds(r.file);
  const size = fs.statSync(r.file).size;
  results.push({ presetId, file: r.file, seconds: sec, expected: r.seconds, sizeMB: (size / 1048576).toFixed(2), ms: Date.now() - t0, bgm: r.hasBgm });
  console.log(`프리셋 ${presetId}: ${path.relative(ROOT, r.file)} | ${sec?.toFixed(2)}초 (계산 ${r.seconds.toFixed(2)}) | ${(size / 1048576).toFixed(2)}MB | ${((Date.now() - t0) / 1000).toFixed(1)}s | 음악 ${r.hasBgm ? "있음" : "없음(파일 없음)"}`);
}
fs.writeFileSync(path.join(ROOT, "output", "_test", "results.json"), JSON.stringify(results, null, 2));
