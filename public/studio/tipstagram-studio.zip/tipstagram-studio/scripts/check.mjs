#!/usr/bin/env node
// 점검 — 뭐가 안 되는지 한눈에. Claude 가 문제를 찾을 때 먼저 실행한다.
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(ROOT);
const IS_WIN = process.platform === "win32";
const ok = (s) => console.log(`✓ ${s}`);
const bad = (s, hint) => console.log(`✗ ${s}${hint ? `\n   → ${hint}` : ""}`);

console.log(`운영체제: ${process.platform} ${os.release()}  Node: ${process.versions.node}  폴더: ${ROOT}\n`);

const sys = fs.existsSync("data/system.json") ? JSON.parse(fs.readFileSync("data/system.json", "utf8")) : null;
sys ? ok(`설치 기록 있음 (${sys.installedAt})`) : bad("설치 기록(data/system.json) 없음", "node scripts/install.mjs 를 실행하세요");

const claude = sys?.claudePath || "claude";
const v = spawnSync(IS_WIN ? `"${claude}"` : claude, ["--version"], { encoding: "utf8", shell: IS_WIN, windowsHide: true });
v.status === 0 ? ok(`claude 실행됨: ${(v.stdout || "").trim()}`) : bad("claude 실행 실패", "Claude Code 설치/로그인 확인");

fs.existsSync("node_modules/next") ? ok("의존성(node_modules) 있음") : bad("node_modules 없음", "npm install");
fs.existsSync(".next/BUILD_ID") ? ok("빌드 결과(.next) 있음") : bad("빌드 안 됨", "node node_modules/next/dist/bin/next build");

const pwCache = IS_WIN ? path.join(process.env.LOCALAPPDATA || "", "ms-playwright") : process.platform === "darwin" ? path.join(os.homedir(), "Library/Caches/ms-playwright") : path.join(os.homedir(), ".cache/ms-playwright");
const hasChromium = fs.existsSync(pwCache) && fs.readdirSync(pwCache).some((d) => d.startsWith("chromium"));
hasChromium ? ok(`Chromium 있음 (${pwCache})`) : bad("Chromium 없음", "node node_modules/playwright/cli.js install chromium");

try {
  const r = await fetch("http://localhost:3777/api/health");
  r.ok ? ok("서버 켜져 있음 (http://localhost:3777)") : bad("서버 응답 이상");
} catch { console.log("· 서버 꺼져 있음 (실행: node scripts/start.mjs)"); }

// 릴스 만들기 쪽
try {
  const ff = (await import("../lib/ffmpeg.js")).ffmpegPath;
  const bin = await ff();
  const r = spawnSync(bin, ["-version"], { encoding: "utf8", windowsHide: true });
  r.status === 0 ? ok(`FFmpeg 있음 (${(r.stdout || "").split("\n")[0].slice(0, 40)})`) : bad("FFmpeg 실행 실패", "npm install 을 다시");
} catch { bad("FFmpeg(ffmpeg-static) 없음", "npm install"); }
const keys = fs.existsSync("data/keys.json") ? JSON.parse(fs.readFileSync("data/keys.json", "utf8")) : {};
keys.gemini ? ok(`Gemini 키 있음 (${keys.image?.ok ? "그림 생성 됨" : "그림 생성은 결제 필요 — 글 분석만"})`) : console.log("· Gemini 키 없음 (설정에서 연결하면 그림 생성·영상 분석이 열려요. 없어도 카드 슬라이드 릴스는 됨)");
const styleSamples = fs.existsSync("public/styles") ? fs.readdirSync("public/styles").filter((f) => /\.(png|jpg|webp)$/.test(f)).length : 0;
styleSamples >= 6 ? ok(`그림체 샘플 ${styleSamples}장`) : bad(`그림체 샘플 ${styleSamples}장 (6장 필요)`, "node scripts/gen-style-samples.mjs (Gemini 키·결제 필요)");
const bgm = ["bright", "calm", "tension"].filter((n) => fs.existsSync(`assets/bgm/${n}.mp3`));
bgm.length === 3 ? ok("배경음악 3곡 있음") : console.log(`· 배경음악 ${bgm.length}/3곡 (assets/bgm/bright.mp3·calm.mp3·tension.mp3 를 넣으면 붙어요. 없으면 무음)`);
const fonts = fs.existsSync("assets/fonts") ? fs.readdirSync("assets/fonts").filter((f) => f.endsWith(".otf")).length : 0;
fonts >= 3 ? ok("영상 자막 글꼴(OTF) 3종") : bad("영상 자막 글꼴 부족", "assets/fonts/Pretendard-*.otf 확인");

const brand = fs.existsSync("data/brand.json") ? JSON.parse(fs.readFileSync("data/brand.json", "utf8")) : null;
brand?.name ? ok(`브랜드 설정됨: ${brand.name} / ${brand.color} / ${brand.topic || "(주제 없음)"} / 그림체 ${brand.artStyle || "photo"}${brand.styleRefFile ? " (내 기준 사진)" : ""}`) : console.log("· 브랜드 설정 아직 안 함 (화면에서 '브랜드 설정')");
