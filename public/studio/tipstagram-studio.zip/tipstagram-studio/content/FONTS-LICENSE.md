# 글꼴 라이선스

`public/fonts/Pretendard-*.woff2` — Pretendard (길형진), SIL Open Font License 1.1.
상업적 사용·배포·수정이 허용된다. 원본: https://github.com/orioncactus/pretendard

# 샘플 사진

`public/sample/sample-photo.webp` — Openverse 에서 받은 CC0(퍼블릭 도메인) 사진. 스타일 고르기 썸네일에만 쓴다.
카드에 실제로 들어가는 사진은 만들 때마다 Openverse(CC0·퍼블릭 도메인 우선)에서 새로 찾거나, 사용자가 직접 올린다.
